return {
  ["workshop-1378549454"]={
    configuration_options={
      ["MemSpikeFix:"]=false,
      MemSpikeFixmaster_override=true,
      ["MemSpikeFixworkshop-1120124958"]="default",
      ["MemSpikeFixworkshop-1179982849"]="default",
      ["MemSpikeFixworkshop-1230820850"]="default",
      ["MemSpikeFixworkshop-1290774114"]="default",
      ["MemSpikeFixworkshop-1324800295"]="default",
      ["MemSpikeFixworkshop-1416911938"]="default",
      ["MemSpikeFixworkshop-343753877"]="default",
      ["MemSpikeFixworkshop-345692228"]="default",
      ["MemSpikeFixworkshop-351325790"]="default",
      ["MemSpikeFixworkshop-356398534"]="default",
      ["MemSpikeFixworkshop-358749986"]="default",
      ["MemSpikeFixworkshop-362175979"]="default",
      ["MemSpikeFixworkshop-365119238"]="default",
      ["MemSpikeFixworkshop-368686576"]="default",
      ["MemSpikeFixworkshop-374550642"]="default",
      ["MemSpikeFixworkshop-375850593"]="default",
      ["MemSpikeFixworkshop-376333686"]="default",
      ["MemSpikeFixworkshop-378160973"]="default",
      ["MemSpikeFixworkshop-382177939"]="default",
      ["MemSpikeFixworkshop-458587300"]="default",
      ["MemSpikeFixworkshop-458940297"]="default",
      ["MemSpikeFixworkshop-462434129"]="default",
      ["MemSpikeFixworkshop-466732225"]="default",
      ["MemSpikeFixworkshop-609051112"]="default",
      ["MemSpikeFixworkshop-666155465"]="default",
      ["MemSpikeFixworkshop-672208231"]="default",
      ["MemSpikeFixworkshop-721491336"]="default",
      ["MemSpikeFixworkshop-758532836"]="default",
      ["MemSpikeFixworkshop-770901818"]="default",
      ["MemSpikeFixworkshop-804413673"]="default",
      ["MemSpikeFixworkshop-818739975"]="default",
      ["MemSpikeFixworkshop-822508420"]="default",
      ["MemSpikeFixworkshop-873350047"]="default",
      ["MemSpikeFixworkshop-972139614"]="default" 
    },
    enabled=true 
  },
  ["workshop-356398534"]={ configuration_options={  }, enabled=true },
  ["workshop-362175979"]={ configuration_options={ ["Draw over FoW"]="disabled" }, enabled=true },
  ["workshop-374550642"]={ configuration_options={ MAXSTACKSIZE=99 }, enabled=true },
  ["workshop-375850593"]={ configuration_options={  }, enabled=true },
  ["workshop-378160973"]={
    configuration_options={
      ENABLEPINGS=true,
      FIREOPTIONS=2,
      OVERRIDEMODE=false,
      SHAREMINIMAPPROGRESS=true,
      SHOWFIREICONS=true,
      SHOWPLAYERICONS=true,
      SHOWPLAYERSOPTIONS=2 
    },
    enabled=true 
  },
  ["workshop-382177939"]={
    configuration_options={ [""]=true, eightxten="5x16", workit="yep" },
    enabled=true 
  },
  ["workshop-458940297"]={
    configuration_options={
      DFV_ClientPrediction="default",
      DFV_FueledSettings="default",
      DFV_Language="EN",
      DFV_MinimalMode="default",
      DFV_PercentReplace="default",
      DFV_ShowACondition="default",
      DFV_ShowADefence="default",
      DFV_ShowAType="off",
      DFV_ShowDamage="default",
      DFV_ShowFireTime="off",
      DFV_ShowInsulation="default",
      DFV_ShowTemperature="default",
      DFV_ShowUses="default" 
    },
    enabled=true 
  },
  ["workshop-466732225"]={ configuration_options={  }, enabled=true },
  ["workshop-666155465"]={
    configuration_options={
      chestB=-1,
      chestG=-1,
      chestR=-1,
      food_estimation=1,
      food_order=1,
      food_style=1,
      lang="en",
      show_food_units=0 
    },
    enabled=true 
  },
  ["workshop-672208231"]={
    configuration_options={
      saddle_basic=0,
      saddle_moon=0,
      saddle_race=0,
      saddle_war=0,
      saddlehorn=0,
      uses=10000000000 
    },
    enabled=true 
  },
  ["workshop-721491336"]={
    configuration_options={
      ["Death Lv Drain (Trust)"]="Off",
      ["General Winter"]="On",
      ["Phoenix's Resilience"]="On",
      ["Survivor's Guilt"]="On",
      Trustworthy="On" 
    },
    enabled=true 
  },
  ["workshop-758532836"]={
    configuration_options={
      AUTOPAUSECONSOLE=false,
      AUTOPAUSEMAP=false,
      AUTOPAUSESINGLEPLAYER=false,
      ENABLECLIENTPAUSING=false,
      ENABLEHOTKEY=false,
      KEYBOARDTOGGLEKEY="P" 
    },
    enabled=true 
  },
  ["workshop-770901818"]={
    configuration_options={ days=2, enable_houndattack=true, format="simple" },
    enabled=true 
  },
  ["workshop-818739975"]={ configuration_options={ DFV_Language="EN" }, enabled=true },
  ["workshop-972139614"]={ configuration_options={ language=1 }, enabled=true } 
}