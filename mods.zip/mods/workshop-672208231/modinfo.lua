--The name of the mod displayed in the 'mods' screen.
name = "Infinite Saddles"

--A description of the mod.
description = "This mod tweaks the durability of saddle things (Saddle, War Saddle, ...) and beefalo mounting time."

author = "QN"
version = "1.05"

forumthread = ""

api_version = 10

icon_atlas = "modicon.xml"
icon = "modicon.tex"

dont_starve_compatible = true
reign_of_giants_compatible = true

all_clients_require_mod = false

dst_compatible = true

server_filter_tags = {"infinite saddles"}


configuration_options =
{
	{
		name = "uses",
		label = "Riding time",
		options = 
		{
		   
			{description = "default", data = 100},  --6s
			{description = "1 minute", data = 1000}, --1M
			{description = "1 day", data = 8000},  --1D
			{description = "Infinite", data = 10000000000}
		},
		default = 10000000000,
	},
	{
		name = "saddle_basic",
		label = "Saddle uses",
		options = 
		{
			{description = "Default (5)", data = "default"},
			{description = "10", data = 2},
			{description = "15", data = 3},
			{description = "20", data = 4},
			{description = "30", data = 6},
			{description = "40", data = 8},
			{description = "50", data = 10},
			{description = "Infinite", data = 0}
		},
		default = 0,
	},
	{
		name = "saddle_war",
		label = "War Saddle uses",
		options = 
		{
			{description = "Default (8)", data = "default"},
			{description = "10", data = 1.25},
			{description = "15", data = 1.875},
			{description = "20", data = 2.5},
			{description = "30", data = 3.75},
			{description = "40", data = 5},
			{description = "50", data = 6.25},
			{description = "Infinite", data = 0}
		},
		default = 0,
	},
	{
		name = "saddle_race",
		label = "Glossamer Saddle uses",
		options = 
		{
			{description = "Default (8)", data = "default"},
			{description = "10", data = 1.25},
			{description = "15", data = 1.875},
			{description = "20", data = 2.5},
			{description = "30", data = 3.75},
			{description = "40", data = 5},
			{description = "50", data = 6.25},
			{description = "Infinite", data = 0}
		},
		default = 0,
	},
	{
		name = "saddlehorn",
		label = "Saddlehorn",
		options = 
		{
			{description = "Default (10)", data = "default"},
			{description = "20", data = 2},
			{description = "30", data = 3},
			{description = "40", data = 4},
			{description = "50", data = 5},
			{description = "Infinite", data = 0}
		},
		default = 0,
	},
	{
		name = "saddle_moon",
		label = "Moon saddle",
		hover = "For \"Domestication Plus\" only",
		options = 
		{
			{description = "Default (10)", data = "default"},
			{description = "20", data = 2},
			{description = "30", data = 3},
			{description = "40", data = 4},
			{description = "50", data = 5},
			{description = "Infinite", data = 0}
		},
		default = 0,
	},
}