if not GLOBAL.TheNet:GetIsClient() then
	-- Remove % on itemslot for infinite items 

	local require = GLOBAL.require
	local ItemTile = require "widgets/itemtile"
	local ItemTile_SetPercent = ItemTile.SetPercent
		function ItemTile:SetPercent(percent)
			if self.item.components.inventoryitem and self.item:HasTag("InfiniteSaddle") then
			-- Nothing
			else
				ItemTile_SetPercent(self, percent)
			end
		end

	function TweakDurability(inst)
		local name = inst.prefab
		local configData = GetModConfigData(name)
		if configData ~= "default" then
			--infinite things
			if configData == 0 then
				inst:AddTag("InfiniteSaddle")
				if inst.components.finiteuses then
					inst.components.finiteuses.Use = function () end
				end
				if inst.components.perishable then
					inst.components.perishable.StartPerishing = function () end
				end
				if inst.components.fueled then
					inst.components.fueled.StartConsuming = function () end
				end
			else
				--tweak things
				if inst.components.finiteuses then
					inst.components.finiteuses.total = (inst.components.finiteuses.total * configData)
					inst.components.finiteuses.current = (inst.components.finiteuses.current * configData)
				end
				if inst.components.perishable then
					inst.components.perishable.perishtime = (inst.components.perishable.perishtime * configData)
					inst.components.perishable.perishremainingtime = (inst.components.perishable.perishremainingtime * configData)
				end
				if inst.components.fueled then                                                                  
					inst.components.fueled.maxfuel = (inst.components.fueled.maxfuel * configData)           
					inst.components.fueled.currentfuel = (inst.components.fueled.currentfuel * configData)   
					inst.components.fueled.bonusmult = (inst.components.fueled.bonusmult * configData)       
				end 
			end
		end
	end

	-- tweak mounting time

	TUNING.BEEFALO_MIN_BUCK_TIME = GetModConfigData("uses")
	TUNING.BEEFALO_MAX_BUCK_TIME = GetModConfigData("uses")

	-- saddle durability

	AddPrefabPostInit("saddle_basic", TweakDurability)
	AddPrefabPostInit("saddle_war", TweakDurability)
	AddPrefabPostInit("saddlehorn", TweakDurability)
	AddPrefabPostInit("saddle_race", TweakDurability)
	
	-- moon saddle
	if GLOBAL.KnownModIndex:IsModEnabled(GLOBAL.KnownModIndex:GetModActualName("Domestication Plus")) then
		AddPrefabPostInit("saddle_moon", TweakDurability)
	end

end