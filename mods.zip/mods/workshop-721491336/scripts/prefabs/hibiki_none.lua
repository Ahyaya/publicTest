local skins = {}
for k,v in pairs(HIBIKISKINS.HIBIKI) do
	local assets = {}
	for skin,anim in pairs(v.builds) do
		table.insert(assets, anim)
	end
	if SKIN_RARITY_COLORS.ModMade ~= nil then table.insert(skins, AddModCharacterSkin("hibiki", k, v.builds, assets, {"HIBIKI", "CHARACTER"}, v.options)) end
end

return CreatePrefabSkin("hibiki_none", {
	base_prefab = "hibiki",
	skins = {
		normal_skin = "hibiki",
		ghost_skin = "ghost_hibiki_build",
		verniy_skin = "verniy"
	},
	assets = {
		Asset( "ANIM", "anim/hibiki.zip" ),
		Asset( "ANIM", "anim/ghost_hibiki_build.zip" ),
		Asset( "ANIM", "anim/verniy.zip" )
	},
	tags = {"HIBIKI", "CHARACTER"},
	skip_item_gen = true,
	skip_giftable_gen = true,
}), unpack(skins)