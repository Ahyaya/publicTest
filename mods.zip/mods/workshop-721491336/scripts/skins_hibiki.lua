local G = GLOBAL
local STRINGS = G.STRINGS

STRINGS.SKIN_QUOTES.hibiki_gangut = "All my comrades who went before me... I'll remember them all."
STRINGS.SKIN_NAMES.hibiki_gangut = "Comrade in Arms"
STRINGS.SKIN_DESCRIPTIONS.hibiki_gangut = "An outfit based off a Fast Russian Battleship."

G.HIBIKISKINS = {
	HIBIKI = {
		["gangut"] = {
			builds = {
				normal_skin = "hibiki_gangut",
				ghost_skin = "ghost_hibiki_build",
				verniy_skin = "verniy_gangut"
			},
			options = {
				avatarset = "hibiki_gangut",
			}
		},
		--[[
		["survivor"] = {
			builds = {
				normal_skin = "erik_survivor",
				ghost_skin = "ghost_erik_build",
				derik_skin = "derik_survivor"
			},
			options = {
				starting_inv_skins = {
					racquet = "destroyerhoundgreen",
					tennisball = "savannahyellow"
				}
			}
		},
		]]--[[
		["shadow"] = {
			builds = {
				normal_skin = "erik_shadow",
				ghost_skin = "ghost_erik_build",
				derik_skin = "derik_shadow"
			},
			options = {
				starting_inv_skins = {
					racquet = "charcoalblack",
					tennisball = "scribbleblack"
				}
			}
		},
		]]--[[
		["rose"] = {
			builds = {
				normal_skin = "erik_rose",
				ghost_skin = "ghost_erik_build",
				derik_skin = "derik_rose"
			},
			options = {
				starting_inv_skins = {
					racquet = "solareclipsered",
					tennisball = nil
				}
			}
		},
		]]--[[
		["bunnyman"] = {
			builds = {
				normal_skin = "erik_bunnyman",
				ghost_skin = "ghost_erik_build",
				derik_skin = "derik_bunnyman"
			},
			options = {
				starting_inv_skins = {
					racquet = "deciduousorange",
					tennisball = nil
				}
			}
		},
		]]--[[
		["spookymovie"] = {
			builds = {
				normal_skin = "erik_spookymovie",
				ghost_skin = "ghost_erik_build",
				derik_skin = "derik_spookymovie"
			},
			options = {
				starting_inv_skins = {
					racquet = "spookypurple",
					tennisball = nil
				}
			}
		},
		]]--[[
		["r63"] = {
			builds = {
				normal_skin = "erik_r63",
				ghost_skin = "ghost_erika_build",
				derik_skin = "derik_r63"
			},
			options = {
				starting_inv_skins = {
					racquet = "regretfulpink",
					tennisball = nil
				},
				avatarset = "erika",
				uiname = "erika",
				gender = "FEMALE"
			}
		},
		]]
	},
	ITEMS = {}
}

if G.SKIN_RARITY_COLORS.ModMade ~= nil then G.MakeModCharacterSkinnable("hibiki") end