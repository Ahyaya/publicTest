--[[
	--- This is Wilson's speech file for Don't Starve Together ---
	Write your character's lines here.
	If you want to use another speech file as a base, or use a more up-to-date version, get them from data\scripts\
	
	If you want to use quotation marks in a quote, put a \ before it.
	Example:
	"Like \"this\"."
]]

return {

	ACTIONFAIL =
	{
        REPAIR =
        {
            WRONGPIECE = "That wasn't right.",
        },
        BUILD =
        {
            MOUNTED = "I'll need to get off, first.",
            HASPET = "I already have another one.",
        },
		SHAVE =
		{
			AWAKEBEEFALO = "Doing that while it's awake is a bad idea.",
			GENERIC = "I can't shave it.",
			NOBITS = "There's nothing left to shave.",
		},
		STORE =
		{
			GENERIC = "It's full.",
			NOTALLOWED = "That can't go in there.",
			INUSE = "It's in use. I'll wait for my turn.",
		},
		RUMMAGE =
		{	
			GENERIC = "I can't do that.",
			INUSE = "I'll wait for my turn.",
		},
		USEKLAUSSACKKEY =
        {
        	WRONGKEY = "That wasn't the right key...",
        	KLAUS = "This isn't the time.",
        },
        COOK =
        {
            GENERIC = "Cooking is impossible right now.",
            INUSE = "Both of us can't cook at the same time.",
            TOOFAR = "I can't cook from this far away.",
        },
        GIVE =
        {
            GENERIC = "I don't think that works.",
            DEAD = "That's a shame...",
            SLEEPING = "Maybe once they wake up.",
            BUSY = "I'll wait until they're done.",
            ABIGAILHEART = "I don't think that works.",
            GHOSTHEART = "I don't want to try that.",
            NOTGEM = "I don't want to try that.",
            WRONGGEM = "I'll need a different gem for this.",
            NOTSTAFF = "It would fit better on a staff.",
            MUSHROOMFARM_NEEDSSHROOM = "A mushroom would probably be of more use.",
            MUSHROOMFARM_NEEDSLOG = "A living log would probably be of more use.",
            SLOTFULL = "Something is already there.",
            DUPLICATE = "We already know that one.",
            NOTSCULPTABLE = "Making that a sculpture is beyond my capabilities.",
			NOTATRIUMKEY = "I don't think it's the correct key.",
            CANTSHADOWREVIVE = "This won't work...",
            WRONGSHADOWFORM = "I don't think this is the right one.",
        },
        GIVETOPLAYER =
        {
        	FULL = "They're carrying too many things...",
            DEAD = "That's a shame...",
            SLEEPING = "Maybe once they wake up.",
            BUSY = "I'll wait until they're done.",
    	},
    	GIVEALLTOPLAYER =
        {
        	FULL = "They're carrying too many things...",
            DEAD = "That's a shame...",
            SLEEPING = "Maybe once they wake up.",
            BUSY = "I'll wait until they're done.",
    	},
        WRITE =
        {
            GENERIC = "That is beyond my capabilities.",
            INUSE = "I'll wait for my turn.",
        },
        DRAW =
        {
            NOIMAGE = "Hmm, what should I draw...",
        },
        CHANGEIN =
        {
            GENERIC = "Not feeling like it.",
            BURNING = "It's too dangerous to do that.",
            INUSE = "It's in use. I'll wait for my turn.",
        },
        ATTUNE =
        {
            NOHEALTH = "I don't feel well enough...",
        },
        MOUNT =
        {
            TARGETINCOMBAT = "It's better not to aggravate it even more.",
            INUSE = "Someone's already using it.",
        },
        SADDLE =
        {
            TARGETINCOMBAT = "I'll need it to calm down first.",
        },
        TEACH =
        {
            --Recipes/Teacher
            KNOWN = "I already learned how to do that one.",
            CANTLEARN = "I can't learn that one.",

            --MapRecorder/MapExplorer
            WRONGWORLD = "This map doesn't work here...",
        },
        WRAPBUNDLE =
        {
            EMPTY = "There's nothing to wrap.",
        },
	},
	ACTIONFAIL_GENERIC = "That is beyond my capabilities.",
	
	ANNOUNCE_DEATH = "My final name is Verniy... Do svidanya...",
	ANNOUNCE_DEATH_RUSSIAN = "My true name is Hibiki... Do svidanya...",
	ANNOUNCE_COMRADE_DEATH = "No...!",
	ANNOUNCE_COMRADE_DEATH_RUSSIAN = "Do svidanya...",
	
	ANNOUNCE_LEVELUP_1 = "Ugh...",
	ANNOUNCE_LEVELUP_2 = "I won't sink.",
	ANNOUNCE_LEVELUP_3 = "As expected, this is embarassing...",
	ANNOUNCE_LEVELUP_4 = "It's all right, even if I am alone.",
	ANNOUNCE_LEVELUP_5 = "...",
	ANNOUNCE_LEVELUP_6 = "The secret of the Phoenix lies in the timing of her repairs.",
	ANNOUNCE_LEVELUP_7 = "I will survive through everything.",
	ANNOUNCE_LEVELUP_8 = "This is why I'm called the Phoenix.",
	ANNOUNCE_LEVELUP_9 = "The name of Phoenix isn't just for show.",
	ANNOUNCE_VERNIY = "Horosho. I can trust in this form...",
	
	ANNOUNCE_DIG_DISEASE_WARNING = "Hopefully this should contain the disease.",
	ANNOUNCE_PICK_DISEASE_WARNING = "...It's diseased. We'll need to contain it.",
	ANNOUNCE_ADVENTUREFAIL = "Mission failed. ...I'll try again.",
    ANNOUNCE_MOUNT_LOWHEALTH = "This beast seems to be wounded.",
	ANNOUNCE_BEES = "Bees!?",
	ANNOUNCE_BOOMERANG = "Ugh, that was embarassing...",
	ANNOUNCE_CHARLIE = "I have a bad feeling about this...",
	ANNOUNCE_CHARLIE_ATTACK = "I can't see what's attacking me...!",
	ANNOUNCE_COLD = "This is nothing compared to Russia.",
	ANNOUNCE_HOT = "Temperatures too high... I'll need to take cover.",
	ANNOUNCE_CRAFTING_FAIL = "I do not have enough resources.",
	ANNOUNCE_DEERCLOPS = "I'm sensing a really large enemy. Be careful.",
	ANNOUNCE_CAVEIN = "The cave is breaking apart...!?",
	ANNOUNCE_ANTLION_SINKHOLE = 
	{
		"Ngh!? Seems like a sinkhole has appeared...",
	},
	ANNOUNCE_ANTLION_TRIBUTE =
	{
        "This should keep it happy for a while.",
	},
	ANNOUNCE_SACREDCHEST_YES = "Horosho. I have the permission to open this.",
	ANNOUNCE_SACREDCHEST_NO = "I was unauthorized.",
	ANNOUNCE_DUSK = "It will be dark soon.",
	ANNOUNCE_EAT =
	{
		GENERIC = "Horosho.",
		PAINFUL = "I don't feel so good...",
		SPOILED = "That didn't taste well...",
		STALE = "I think that was starting to turn.",
		INVALID = "I cannot eat this.",
		YUCKY = "I refuse.",
	},
    ANNOUNCE_ENCUMBERED =
    {
        "Ngh...",
        "It's so... heavy...",
        "Huff...",
        "Hngh...!",
        "It's heavy, but I have to...!",
        "Pant... Pant...",
        "This is nothing...!",
    },
	ANNOUNCE_ATRIUM_DESTABILIZING = 
    {
		"I think we should leave. Now.",
	},
    ANNOUNCE_RUINS_RESET = "Looks like the monsters have returned.",
    ANNOUNCE_SNARED = "Ngh...! I can't move!",
    ANNOUNCE_REPELLED = "Tch, it's protecting itself.",
	ANNOUNCE_ENTER_DARK = "It's dark.",
	ANNOUNCE_ENTER_LIGHT = "Vision restored.",
	ANNOUNCE_FREEDOM = "Freedom. That's a nice sound. I like it.",
	ANNOUNCE_HIGHRESEARCH = "Intel obtained.",
	ANNOUNCE_HOUNDS = "I'm hearing wolves. Be careful.",
	ANNOUNCE_WORMS = "I'm detecting movement from the ground.",
	ANNOUNCE_HUNGRY = "...I'm hungry.",
	ANNOUNCE_HUNT_BEAST_NEARBY = "There's an animal we can hunt nearby.",
	ANNOUNCE_HUNT_LOST_TRAIL = "Tch, we lost the trail.",
	ANNOUNCE_HUNT_LOST_TRAIL_SPRING = "The ground is too wet for the trail to last.",
	ANNOUNCE_INV_FULL = "It won't fit in my inventory.",
	ANNOUNCE_KNOCKEDOUT = "Ugh...",
	ANNOUNCE_LOWRESEARCH = "Failed to obtain intel...",
	ANNOUNCE_MOSQUITOS = "Stop that.",
    ANNOUNCE_NOWARDROBEONFIRE = "It's on fire...",
    ANNOUNCE_NODANGERGIFT = "It's too dangerous to open it right now.",
    ANNOUNCE_NOMOUNTEDGIFT = "I should get off, first.",
	ANNOUNCE_NODANGERSLEEP = "There are enemies nearby. It's too dangerous.",
	ANNOUNCE_NODAYSLEEP = "It's too bright out...",
	ANNOUNCE_NODAYSLEEP_CAVE = "I'm not tired yet.",
	ANNOUNCE_NOHUNGERSLEEP = "I'm too hungry to sleep...",
	ANNOUNCE_NOSLEEPONFIRE = "Sleeping in that is too risky.",
	ANNOUNCE_NODANGERSIESTA = "It's too dangerous to take a nap.",
	ANNOUNCE_NONIGHTSIESTA = "I should be sleeping instead.",
	ANNOUNCE_NONIGHTSIESTA_CAVE = "I don't think I could really relax down here.",
	ANNOUNCE_NOHUNGERSIESTA = "I'm too hungry for this.",
	ANNOUNCE_NODANGERAFK = "I can't retreat here!",
	ANNOUNCE_NO_TRAP = "Well, that was easy.",
	ANNOUNCE_PECKED = "Ngh...!",
	ANNOUNCE_QUAKE = "An earthquake...!?",
	ANNOUNCE_RESEARCH = "Gathering intel.",
	ANNOUNCE_SHELTER = "I'll temporarily take shelter here.",
	ANNOUNCE_THORNS = "Ngh...!",
	ANNOUNCE_BURNT = "As expected, that was embarassing...",
	ANNOUNCE_TORCH_OUT = "My light ran out.",
	ANNOUNCE_THURIBLE_OUT = "The shadows stopped following me.",
	ANNOUNCE_FAN_OUT = "My fan stopped working.",
    ANNOUNCE_COMPASS_OUT = "This compass stopped working.",
	ANNOUNCE_TRAP_WENT_OFF = "Ah.",
	ANNOUNCE_UNIMPLEMENTED = "I don't think it's ready yet.",
	ANNOUNCE_WORMHOLE = "Urgh. Now I'm sticky all over...",
	ANNOUNCE_TOWNPORTALTELEPORT = "Safely arrived at the destination.",
	ANNOUNCE_CANFIX = "\nThat can be fixed.",
	ANNOUNCE_ACCOMPLISHMENT = "Mission Complete.",
	ANNOUNCE_ACCOMPLISHMENT_DONE = "Horosho.",	
	ANNOUNCE_INSUFFICIENTFERTILIZER = "I ran out of fertilizer.",
	ANNOUNCE_TOOL_SLIP = "Ngh!? Oh no...!",
	ANNOUNCE_LIGHTNING_DAMAGE_AVOIDED = "Lightning damage avoided.",
	ANNOUNCE_TOADESCAPING = "The toad is escaping...",
	ANNOUNCE_TOADESCAPED = "The toad got away.",

	ANNOUNCE_DAMP = "It's quite damp.",
	ANNOUNCE_WET = "Water doesn't bother me.",
	ANNOUNCE_WETTER = "I'm taking in water.",
	ANNOUNCE_SOAKED = "Taking in dangerous amounts of water...!",
	
	ANNOUNCE_BECOMEGHOST = "Do Svidanya...",
	ANNOUNCE_GHOSTDRAIN = "I feel something's up...",
	ANNOUNCE_PETRIFED_TREES = "The trees are screaming...",
	ANNOUNCE_KLAUS_ENRAGE = "It's angry. Be careful!",
	ANNOUNCE_KLAUS_UNCHAINED = "It broke free...!",
	ANNOUNCE_KLAUS_CALLFORHELP = "It's calling for help!",

    ANNOUNCE_ROYALTY = 
    {
    	"Your majesty.",
    	"Your highness.",
    	"My liege.",
    },

	BATTLECRY =
	{
		GENERIC = "Ura-!",
		PIG = "It's futile.",
		PREY = "It's futile.",
		SPIDER = "Too slow.",
		SPIDER_WARRIOR = "Ura-!",
	},
	COMBAT_QUIT =
	{
		GENERIC = "Drove away the enemy.",
		PIG = "Enemy escaped...",
		PREY = "Enemy escaped...",
	},
	DESCRIBE =
	{
		MULTIPLAYER_PORTAL = "It's a strange-looking portal... Did I come through here?",
		ANTLION = 
		{
			GENERIC = "It's big, but it doesn't look hostile?",
			VERYHAPPY = "Horosho. I think it's satisfied.",
			UNHAPPY = "I don't think it's very happy.",
		},
		ANTLIONTRINKET = "It's a beach toy set... where'd this come from?",
		SANDSPIKE = "Getting hit by that wouldn't be pleasant.",
        SANDBLOCK = "Let's not let it block our path.",
        GLASSSPIKE = "A transparent and somewhat pretty spike.",
        GLASSBLOCK = "It looks really pretty.",
		ABIGAIL_FLOWER = 
		{ 
			GENERIC ="It's a beautiful, but somewhat creepy flower...",
			HAUNTED_POCKET = "A chill went down my spine... I think this is a bad idea.",
			HAUNTED_GROUND = "It gives off a very chilly aura.",
		},

		BALLOONS_EMPTY = "Someone should blow into them.",
		BALLOON = "Reminds me of the past...",

		BERNIE_INACTIVE =
		{
			BROKEN = "It finally fell apart.",
			GENERIC = "It's all scorched.",
		},

		BERNIE_ACTIVE = "That teddy bear is moving around. Interesting.",
		
		BOOK_BIRDS = "I love birds. Phoenixes in particular.",
		BOOK_TENTACLES = "Human anatomy is... interesting.",
		BOOK_GARDENING = "I want to grow my own garden someday.",
		BOOK_SLEEP = "Ah, the memories of reading this to my sisters...",
		BOOK_BRIMSTONE = "A very disturbing book. I like it.",
		
		PLAYER =
        {
            GENERIC = "It's %s.",
            ATTACKER = "I feel like %s is scheming something...",
            MURDERER = "What are you doing!?",
            REVIVER = "%s, that was very nice of you.",
            GHOST = "%s? Is that you?",
        },
		
		HIBIKI =
        {
            GENERIC = "A comrade. Horosho.",
            ATTACKER = "My other self seems suspicious.",
            MURDERER = "Why did you murder them...?",
            REVIVER = "Horosho. Thanks, me.",
            GHOST = "There's something very wrong with this sight...",
        },
		INAZUMA = 
		{
			GENERIC = "I'm glad you're here with me, Inazuma.",
            ATTACKER = "Inazuma, did something happen?",
            MURDERER = "Inazuma's hands are trembling... It can't be...?",
            REVIVER = "Inazuma, you're truly an angel.",
            GHOST = "Inazuma? No... No! Not again...",
		},
		IKAZUCHI = 
		{
			GENERIC = "Ikazuchi. You're handy to have around.",
            ATTACKER = "Ikazuchi!? What were you doing...?",
            MURDERER = "Ikazuchi, why did you...?",
            REVIVER = "I can always rely on you, Ikazuchi.",
            GHOST = "Ikazuchi...? Not you, too...",
		},
		AKATSUKI = 
		{
			GENERIC = "Ah, big sister Akatsuki. I hope you're doing well.",
            ATTACKER = "Akatsuki!? What did you just do?",
            MURDERER = "Akatsuki, what pushed you to do this...?",
            REVIVER = "Thanks for helping out, Akatsuki.",
            GHOST = "Akatsuki...? Argh... I'm having flashbacks...",
		},
		SHIRANUI = 
		{
			GENERIC = "Shiranui, watch my back.",
            ATTACKER = "Shiranui seems more silent than usual today.",
            MURDERER = "Shiranui is covered in blood...",
            REVIVER = "Shiranui, thanks for helping out.",
            GHOST = "Shiranui...? What happened to...!?",
		},
		SHIGURE = 
		{
			GENERIC = "Pleased to be here with you, Shigure.",
            ATTACKER = "Shigure's smile is a little off today...",
            MURDERER = "Shigure's a little red...",
            REVIVER = "Shigure, thanks for helping out.",
            GHOST = "Shigure...? Is that you?",
		},
		SATSUKI = 
		{
			GENERIC = "Hello there, Satsuki. How's it been?",
            ATTACKER = "Satsuki is scheming something...",
            MURDERER = "Satsuki, what did you do...!?",
            REVIVER = "Satsuki, thanks for helping out.",
            GHOST = "Satsuki...? Did you...?",
		},
		KISO = 
		{
			GENERIC = "Greetings, Kiso. Is there anything you need of me?",
            ATTACKER = "Kiso's been attacking others...",
            MURDERER = "Kiso, what's gotten into you...!?",
            REVIVER = "Thank you for helping them out, Kiso.",
            GHOST = "Kiso...? What could have happened?",
		},
		RYUUJOU = 
		{
			GENERIC = "Greetings, Ryuujou. Is everything alright?",
            ATTACKER = "Ryuujou? Why did you attack them!?",
            MURDERER = "Ryuujou, did you really need to do that...!?",
            REVIVER = "Ryuujou, thanks for helping them out.",
            GHOST = "Ryuujou...? What could have happened?",
		},
		TAIYOU = 
		{
			GENERIC = "Ah, it's Taiyou. How's Chuuyou?",
            ATTACKER = "Taiyou, did they do something to you?",
            MURDERER = "Taiyou, I don't think your sisters would like that.",
            REVIVER = "Thanks for helping them out, Taiyou.",
            GHOST = "Taiyou, please rest in peace.",
		},
		AKIZUKI = 
		{
			GENERIC = "Hello, Akizuki. I hope you have enough food.",
            ATTACKER = "Akizuki looks... dangerous.",
            MURDERER = "Akizuki, what is the meaning of this...?",
            REVIVER = "Thanks for helping them out, Akizuki.",
            GHOST = "Akizuki... At least she won't starve now.",
		},
		
        MIGRATION_PORTAL = 
        {
            GENERIC = "It's a portal to another world. Interesting.",
            OPEN = "Maybe visiting another world would be interesting.",
            FULL = "I don't seem to be able to enter...",
        },
		GLOMMER = "...What's that? It's... sort of cute.",
		GLOMMERFLOWER = 
		{
			GENERIC = "Seems like that creature follows me when I carry this.",
			DEAD = "As the creature falls, so does the flower...",
		},
		GLOMMERWINGS = "Wings belonging to an innocent creature.",
		GLOMMERFUEL = "This liquid smells... wrong.",
		BELL = "Ding dong.",
		STATUEGLOMMER = 
		{	
			GENERIC = "It's a statue of a fly-like creature.",
			EMPTY = "It's broken...",
		},

		LAVA_POND_ROCK = "That doesn't look very safe.",
		LAVA_POND_ROCK2 = "That doesn't look very safe.",
		LAVA_POND_ROCK3 = "That doesn't look very safe.",
		LAVA_POND_ROCK4 = "That doesn't look very safe.",
		LAVA_POND_ROCK5 = "That doesn't look very safe.",
		LAVA_POND_ROCK6 = "That doesn't look very safe.",
		LAVA_POND_ROCK7 = "That doesn't look very safe.",

		WEBBERSKULL = "This doesn't seem like this belonged to a human.",
		WORMLIGHT = "A glowing fruit.",
		WORMLIGHT_LESSER = "An unhealthy looking fruit.",
		WORM =
		{
		    PLANT = "This looks suspicious...",
		    DIRT = "It's moving underground...!",
		    WORM = "Worm detected!",
		},
        WORMLIGHT_PLANT = "Looks suspicious.",
		MOLE =
		{
			HELD = "It can't dig out of this situation.",
			UNDERGROUND = "There's a mole hunting for minerals down there.",
			ABOVEGROUND = "What a cute mole, but I feel an urge to whack it...",
		},
		MOLEHILL = "Is this where they kept all the resources they stole?",
		MOLEHAT = "It stinks, but it gives me night vision.",

		EEL = "This will make a delicious meal.",
		EEL_COOKED = "Horosho. It's all crispy.",
		UNAGI = "This will make a delicious meal.",
		EYETURRET = "Let's avoid getting spotted.",
		EYETURRET_ITEM = "It seems to be deactivated.",
		MINOTAURHORN = "This is a large, sturdy horn.",
		MINOTAURCHEST = "I wonder what it's guarding...",
		THULECITE_PIECES = "Small chunks of some sort of material.",
		POND_ALGAE = "Some algae by a pond.",
		GREENSTAFF = "This could help save up on resources.",
		GIFT = "A giftbox...? Who could this be for?",
        GIFTWRAP = "Horosho. I can use this to wrap gifts.",
		POTTEDFERN = "It's a simple decorative plant.",
		SUCCULENT_POTTED = "Horosho. They look nice as decorations.",
		SUCCULENT_PLANT = "Some desert plants.",
		SUCCULENT_PICKED = "The sap has some healing properties.",
		SENTRYWARD = "It reveals things hidden in the fog.",
        TOWNPORTAL =
        {
			GENERIC = "Travelling with the power of sand.",
			ACTIVE = "Someone's ready to return home.",
		},
        TOWNPORTALTALISMAN = 
        {
			GENERIC = "The sand in this stone is trying to return somewhere.",
			ACTIVE = "It's ready to return home.",
		},
        WETPAPER = "Whatever was written there, it's gone now.",
        WETPOUCH = "It's as if the pouch itself is melting.",
		MOONROCK_PIECES = "It looks breakable...",
        MOONBASE =
        {
            GENERIC = "There's a slot where a staff would go in...",
            BROKEN = "It's completely broken...",
            STAFFED = "Horosho...!",
            WRONGSTAFF = "This isn't the right staff.",
            MOONSTAFF = "The stone is lighting up...!?",
        },
        MOONDIAL = 
        {
			GENERIC = "This device allows us to see what the moon is doing.",
			NIGHT_NEW = "It's a new moon.",
			NIGHT_WAX = "The moon is waxing.",
			NIGHT_FULL = "It's a full moon.",
			NIGHT_WANE = "The moon is waning.",
			CAVE = "The moon is not visible from down here.",
        },
 		--MOWER = "I like the cut of this blade.",
		--MACHETE = "I like the cut of this blade.",
		--GOLDENMACHETE = "Hack in style!",
		--OBSIDIANMACHETE = "It's hot to the touch.",
		--BOOK_METEOR = "The foreword just says \"Hope you like dragoons.\"",
		THULECITE = "It's a large chunk of some strong material.",
		ARMORRUINS = "It's light, but it's amazingly tough.",
		RUINS_BAT = "It's almost weightless, but it's very strong.",
		RUINSHAT = "It shines bright.",
		NIGHTMARE_TIMEPIECE =
		{
            CALM = "Nothing seems to be happening.",
            WARN = "I'm sensing something...",
            WAXING = "I have a bad feeling about this...!",
            STEADY = "The readings aren't changing.",
            WANING = "The nightmare is decreasing...",
            DAWN = "The nightmare is almost gone.",
            NOMAGIC = "I don't feel anything in this location...",
		},
		BISHOP_NIGHTMARE = "It can't hold its form...",
		ROOK_NIGHTMARE = "That's a terrifying creature.",
		KNIGHT_NIGHTMARE = "I've always been good at chess, and this is no exception.",
		MINOTAUR = "It's ready to charge at any time.",
		SPIDER_DROPPER = "Be on guard, they might drop on you at any time.",
		NIGHTMARELIGHT = "It's emitting light, but it doesn't feel good...",
		NIGHTSTICK = "It's not an actual morning star, but close enough.",
		GREENGEM = "It's a green gem.",
		RELIC = "These seem like ordinary household objects...",
		MULTITOOL_AXE_PICKAXE = "Horosho. Resource gathering will be more efficient.",
		ORANGESTAFF = "This will allow me to teleport.",
		YELLOWAMULET = "It's warm...",
		GREENAMULET = "It makes me strangely productive...!",
		SLURPERPELT = "A ball of fur and meat.",	

		SLURPER = "It looks very hungry...",
		SLURPER_PELT = "A ball of fur and meat.",
		ARMORSLURPER = "A wearable ball of fur and meat.",
		ORANGEAMULET = "It draws items to me. Convenient.",
		YELLOWSTAFF = "It emits a very warm light.",
		YELLOWGEM = "A yellow gem.",
		ORANGEGEM = "A very orange gem.",
        OPALSTAFF = "It feels like it has a connection with the moon...",
        OPALPRECIOUSGEM = "This gem feels special...",
        TELEBASE = 
		{
			VALID = "It's ready.",
			GEMS = "It needs more purple gems.",
		},
		GEMSOCKET = 
		{
			VALID = "It's ready.",
			GEMS = "It needs a gem.",
		},
		STAFFLIGHT = "It's warm...",
        STAFFCOLDLIGHT = "It's sort of cooling.",

        ANCIENT_ALTAR = "It's a very mysterious structure...",

        ANCIENT_ALTAR_BROKEN = "A broken mysterious structure.",

        ANCIENT_STATUE = "A mysterious, ancient statue.",

        LICHEN = "Found in caves. Would be a bad idea to eat raw.",
		CUTLICHEN = "Nutritious, but it won't last long.",

		CAVE_BANANA = "It's mushy.",
		CAVE_BANANA_COOKED = "Horosho.",
		CAVE_BANANA_TREE = "How did it grow without light...?",
		ROCKY = "Tough looking creatures. It looks... cool.",
		
		COMPASS =
		{
			GENERIC="It's always useful to have.",
			N = "North.",
			S = "South.",
			E = "East.",
			W = "West.",
			NE = "Northeast.",
			SE = "Southeast.",
			NW = "Northwest.",
			SW = "Southwest.",
		},

        HOUNDSTOOTH = "Ours was the better pack.",
		ARMORSNURTLESHELL = "Horosho. It's sturdy and strong.",
		BAT = "Ah, a bat.",
		BATBAT = "I wonder if I could fly with two of these.",
        BATWING = "A bat wing.",
		BATWING_COOKED = "Surprisingly delicious.",
        BATCAVE = "A cave full of bats.",
		BEDROLL_FURRY = "It's so warm and comfy.",
        BUNNYMAN = "They remind me of those theme park bunny mascots.",
        FLOWER_CAVE = "It glows.",
        FLOWER_CAVE_DOUBLE = "It glows.",
        FLOWER_CAVE_TRIPLE = "It glows.",
        GUANO = "It's... bat excrement.",
        LANTERN = "A stronger, longer-lasting light.",
        LIGHTBULB = "It's essentially a lightbulb.",
        MANRABBIT_TAIL = "I just like holding it.",
        MUSHROOMHAT = "I feel the urge to dance when I wear it...",
        MUSHROOM_LIGHT2 =
        {
            ON = "It has a very cool glow.",
            OFF = "Seems like it could start glowing at any moment.",
            BURNT = "It burnt down...",
        },
        MUSHROOM_LIGHT =
        {
            ON = "It somehow lit up.",
            OFF = "It's a very large mushroom.",
            BURNT = "It burnt down...",
        },
        MUSHROOMBOMB = "Gives me war flashbacks...",
        SHROOM_SKIN = "Slimy.",
        TOADSTOOL_CAP =
        {
            EMPTY = "An empty hole in the ground.",
            INGROUND = "Something's growing out of it...!",
            GENERIC = "I have a feeling we should cut it down.",
        },
        TOADSTOOL =
        {
            GENERIC = "A large and toxic frog. Be careful.",
            RAGE = "It's angry. Watch out!",
        },
        MUSHROOMSPROUT =
        {
            GENERIC = "I have a feeling we should cut it down.",
            BURNT = "It's burnt down...",
        },
        MUSHTREE_TALL =
        {
            GENERIC = "A really large mushroom tree.",
            BLOOM = "You can't tell by looking, but it's smelly.",
        },
        MUSHTREE_MEDIUM =
        {
            GENERIC = "These are some large mushrooms.",
            BLOOM = "It's blooming...?",
        },
        MUSHTREE_SMALL =
        {
            GENERIC = "A small mushroom tree.",
            BLOOM = "It's trying to reproduce...",
        },
        MUSHTREE_TALL_WEBBED = "It's all webbed up...",
        SPORE_TALL = "It's floating around.",
        SPORE_MEDIUM = "It's floating around.",
        SPORE_SMALL = "It's floating around.",
        SPORE_TALL_INV = "It's glowing even in my pockets...",
        SPORE_MEDIUM_INV = "It's glowing even in my pockets...",
        SPORE_SMALL_INV = "It's glowing even in my pockets...",
        RABBITHOUSE =
        {
            GENERIC = "A carrot house. Appropriate.",
            BURNT = "It burnt down...",
        },
        SLURTLE = "It's some sort of shelled creature.",
        SLURTLE_SHELLPIECES = "Pieces of a broken shell.",
        SLURTLEHAT = "It's very strong and offers a lot of protection.",
        SLURTLEHOLE = "A den of these shelled things.",
        SLURTLESLIME = "A strangely flammable material.",
        SNURTLE = "This one has a different shell.",
        SPIDER_HIDER = "A surprise attack-!? How smart are these spiders...!?",
		SPIDER_SPITTER = "These ones spit sticky web at you.",
		SPIDERHOLE = "A rock infested with spiders. Be cautious around it.",
        SPIDERHOLE_ROCK = "A rock infested with spiders. Be cautious around it.",
        STALAGMITE = "A small rock formation.",
        STALAGMITE_FULL = "A small rock formation.",
        STALAGMITE_LOW = "A small rock formation.",
        STALAGMITE_MED = "A small rock formation.",
        STALAGMITE_TALL = "A slightly taller rock formation.",
        STALAGMITE_TALL_FULL = "A slightly taller rock formation.",
        STALAGMITE_TALL_LOW = "A slightly taller rock formation.",
        STALAGMITE_TALL_MED = "A slightly taller rock formation.",
        TREASURECHEST_TRAP = "A very... suspicious chest.",

        TURF_CARPETFLOOR = "Horosho. This will make resting easier.",
        TURF_CHECKERFLOOR = "A very fashionable-looking floorpiece.",
        TURF_DIRT = "Dirty.",
        TURF_FOREST = "A chunk of ground.",
        TURF_GRASS = "A chunk of ground.",
        TURF_MARSH = "A chunk of ground.",
        TURF_ROAD = "A cobblestone path.",
        TURF_ROCKY = "A chunk of ground.",
        TURF_SAVANNA = "A chunk of ground.",
        TURF_WOODFLOOR = "Flammable, but comfortable.",

		TURF_CAVE = "Yet another ground type.",
		TURF_FUNGUS = "Yet another ground type.",
		TURF_SINKHOLE = "Yet another ground type.",
		TURF_UNDERROCK = "Yet another ground type.",
		TURF_MUD = "Yet another ground type.",

		TURF_DECIDUOUS = "Yet another ground type.",
		TURF_SANDY = "Yet another ground type.",
		TURF_BADLANDS = "Yet another ground type.",
		TURF_DESERTDIRT = "A chunk of ground.",
		TURF_FUNGUS_GREEN = "A chunk of ground.",
		TURF_FUNGUS_RED = "A chunk of ground.",
		TURF_DRAGONFLY = "It had to be fireproof to handle the dragonfly.",

		POWCAKE = "It's sweet.",
        CAVE_ENTRANCE = "I wonder if I could move that rock.",
        CAVE_ENTRANCE_RUINS = "I feel like it's hiding something...",
       
       	CAVE_ENTRANCE_OPEN = 
        {
            GENERIC = "I don't really want to go in there.",
            OPEN = "A cold breeze blows from inside the hole...",
            FULL = "I'll have to wait until someone leaves.",
        },
        CAVE_EXIT = 
        {
            GENERIC = "I'll stay down here for now...",
            OPEN = "I think it's about time I see light again.",
            FULL = "The surface is too crowded.",
        },

		MAXWELLPHONOGRAPH = "Huh. So that's where the music was from.",
		BOOMERANG = "Impractical to use, but they're strong.",
		PIGGUARD = "That looks like a hostile. I'll be cautious.",
		ABIGAIL = "Is that a ghost...?",
		ADVENTURE_PORTAL = "I wonder where this portal leads to...",
		AMULET = "I feel so safe when I'm wearing it.",
		ANIMAL_TRACK = "Tracks left by an animal.",
		ARMORGRASS = "It's quite uncomfortable with the insects around.",
		ARMORMARBLE = "A really heavy, but tough armor.",
		ARMORWOOD = "It's quite uncomfortable with the insects around.",
		ARMOR_SANITY = "I'm not sure how this protects me.",
		ASH =
		{
			GENERIC = "It burnt down...",
			REMAINS_GLOMMERFLOWER = "The flower was consumed by fire when I teleported.",
			REMAINS_EYE_BONE = "The eyebone was consumed by fire when I teleported.",
			REMAINS_THINGIE = "This was once something before it got burnt...",
		},
		AXE = "It's a trusty axe.",
		BABYBEEFALO = 
		{
			GENERIC = "A baby Beefalo. Cute.",
		    SLEEPING = "It's even cuter when it's sleeping.",
        },
        BUNDLE = "A bundle of supplies.",
        BUNDLEWRAP = "Wrapped up bundle of supplies.",
		BACKPACK = "We can use this bag to carry more things.",
		BACONEGGS = "A perfectly American breakfast.",
		BANDAGE = "First aid.",
		BASALT = "That's too strong to break through.",
		BEARDHAIR = "It's beard hair. But, from who...?",
		BEARGER = "That's a dangerous-looking creature.",
		BEARGERVEST = "A very furry vest. It's warm.",
		ICEPACK = "A backpack laced with fur. It's cool.",
		BEARGER_FUR = "A pile of very thick fur.",
		BEDROLL_STRAW = "It helps me sleep better at night.",
		BEEQUEEN = "A large insect enemy detected.",
		BEEQUEENHIVE = 
		{
			GENERIC = "It's covered with sticky honey.",
			GROWING = "It's a growing bee hive.",
		},
        BEEQUEENHIVEGROWN = "The beehive grew so big in a short span of time...",
        BEEGUARD = "These smaller ones protect the queen...!",
        HIVEHAT = "This crown makes me feel... secure.",
        MINISIGN =
        {
            GENERIC = "That's a good drawing. Very cute.",
            UNDRAWN = "It's empty. Someone should write something on it.",
        },
        MINISIGN_ITEM = "This sign needs to be placed down.",
		BEE =
		{
			GENERIC = "Bee careful not to get stung.",
			HELD = "Don't bee ridiculous.",
		},
		BEEBOX =
		{
			READY = "It's full of honey.",
			FULLHONEY = "It's full of honey.",
			GENERIC = "It's full of bees.",
			NOHONEY = "It's empty.",
			SOMEHONEY = "I should wait a little more.",
			BURNT = "It burnt down...",
		},
		MUSHROOM_FARM =
		{
			STUFFED = "That's a lot of mushrooms.",
			LOTS = "The mushrooms are growing rapidly.",
			SOME = "It's steadily growing.",
			EMPTY = "It's empty. It needs some spores.",
			ROTTEN = "The log is rotten. It needs to be replaced.",
			BURNT = "It burnt down...",
			SNOWCOVERED = "It's too cold to grow anything.",
		},
		BEEFALO =
		{
			FOLLOWER = "We managed to bring along one home.",
			GENERIC = "It's a beefalo.",
			NAKED = "It's completely stripped off of its fur.",
			SLEEPING = "It's almost impossible to wake them up...",
            --Domesticated states:
            DOMESTICATED = "It's a domesticated beefalo.",
            ORNERY = "This one looks ready to fight.",
            RIDER = "This one feels like it wants to be ridden.",
            PUDGY = "We may have given this one a little too much food.",
		},

		BEEFALOHAT = "Horosho. This hat makes me feel powerful.",
		BEEFALOWOOL = "Freshly shaved from a beefalo.",
		BEEHAT = "Helps against bee attacks.",
        BEESWAX = "A material useful for sticking things together.",
		BEEHIVE = "It's full of bees.",
		BEEMINE = "Handle with care.",
		BEEMINE_MAXWELL = "It's swarming with mosquitoes...",
		BERRIES = "I prefer blueberries.",
		BERRIES_COOKED = "I still prefer blueberries, but this will do.",
        BERRIES_JUICY = "Juicy berries. Very delicious, but easy to spoil.",
        BERRIES_JUICY_COOKED = "Cooked, juicy berries. Better hurry and eat them.",
		BERRYBUSH =
		{
			BARREN = "Needs some fertilization.",
			WITHERED = "It's too hot for it to grow anything...",
			GENERIC = "It grows berries.",
			PICKED = "The berries will grow back after a while.",
			DISEASED = "It's diseased...",
			DISEASING = "The berry bush doesn't look well.",
			BURNING = "We need to put the fire out!",
		},
		BERRYBUSH_JUICY =
		{
			BARREN = "It needs more fertilizers.",
			WITHERED = "It's completely dehydrated.",
			GENERIC = "It grows slightly juicier berries.",
			PICKED = "The berries will grow back after a while.",
			DISEASED = "It's diseased...",
			DISEASING = "The berry bush doesn't look well.",
			BURNING = "We need to put the fire out!",
		},
		BIGFOOT = "What left this giant footprint?",
		BIRDCAGE =
		{
			GENERIC = "I should put a bird in it.",
			OCCUPIED = "That's my bird.",
			SLEEPING = "Ah, he's asleep.",
			HUNGRY = "He seems hungry.",
			STARVING = "He's starving, I really need to feed him soon.",
			DEAD = "Oh no...",
			SKELETON = "...Rest in peace...",
		},
		BIRDTRAP = "If we need to catch birds, this is the tool for it.",
		CAVE_BANANA_BURNT = "It burnt down...",
		BIRD_EGG = "Egg procured. Heading back to base.",
		BIRD_EGG_COOKED = "A cooked egg. Horosho.",
		BISHOP = "Be careful of the balls it shoots out!",
		BLOWDART_FIRE = "This looks dangerous to use.",
		BLOWDART_SLEEP = "Useful for hunting.",
		BLOWDART_PIPE = "We can use this to shoot blowdarts.",
		BLOWDART_YELLOW = "I'll use this in your memory.",
		BLUEAMULET = "It's a cool amulet.",
		BLUEGEM = "It's surrounded by a cool breeze.",
		BLUEPRINT = 
		{ 
            COMMON = "These are plans we can use to make better things.",
            RARE = "Horosho! These are particularly useful things.",
        },
        SKETCH = "A picture of a sculpture we can make somewhere else.",
		--BELL_BLUEPRINT = "There's SCIENCE afoot!",
		BLUE_CAP = "It's a blue mushroom.",
		BLUE_CAP_COOKED = "Does it have different effects now?",
		BLUE_MUSHROOM =
		{
			GENERIC = "It's a blue mushroom.",
			INGROUND = "It's sleeping.",
			PICKED = "It'll grow back eventually.",
		},
		BOARDS = "Strong, flat boards.",
		BONESHARD = "Some of it is finely grounded into powder.",
		BONESTEW = "It's full of bones.",
		BUGNET = "Reminds me of that incident with Ikazuchi...",
		BUSHHAT = "It's tactical camouflage.",
		BUTTER = "I can't believe it's... butter.",
		BUTTERFLY =
		{
			GENERIC = "It's a butterfly. Pretty.",
			HELD = "It doesn't feel good putting it in my pockets.",
		},
		BUTTERFLYMUFFIN = "There's some remnants of the butterfly on top.",
		BUTTERFLYWINGS = "Beautiful. It's sad the butterfly had to die.",
		BUZZARD = "Birds of prey.",

		SHADOWDIGGER = "Are those shadow clones...?",

		CACTUS = 
		{
			GENERIC = "Sharp, but delicious.",
			PICKED = "Careful not to get pricked.",
		},
		CACTUS_MEAT_COOKED = "Spine-free and cooked.",
		CACTUS_MEAT = "There's still a few more spines left.",
		CACTUS_FLOWER = "The prettier the flowers, the more dangerous the plant.",

		COLDFIRE =
		{
			EMBERS = "I should put something on the fire before it goes out.",
			GENERIC = "Horosho. That's a beautiful-looking fire.",
			HIGH = "That fire is getting out of hand.",
			LOW = "The fire's getting a bit low.",
			NORMAL = "Nice and comfy.",
			OUT = "The fire is out.",
		},
		CAMPFIRE =
		{
			EMBERS = "I should put something on the fire before it goes out.",
			GENERIC = "It's warm.",
			HIGH = "That fire is getting out of hand.",
			LOW = "The fire's getting a bit low.",
			NORMAL = "Nice and comfy.",
			OUT = "The fire is out.",
		},
		CANE = "It makes walking seem much easier.",
		CATCOON = "A playful little animal.",
		CATCOONDEN = 
		{
			GENERIC = "It's a tree den. Something's in it.",
			EMPTY = "Nobody's home.",
		},
		CATCOONHAT = "This reminds me of the Russian winter.",
		COONTAIL = "I can still feel it moving.",
		CARROT = "It's what rabbits would like.",
		CARROT_COOKED = "Crunchy.",
		CARROT_PLANTED = "It's growing into a fine carrot.",
		CARROT_SEEDS = "It's a carrot seed.",
		CARTOGRAPHYDESK = 
		{	
			GENERIC = "We can make map scrolls for easier navigation.",
			BURNING = "We have to put it out!",
			BURNT = "It burnt down...",
		},
		WATERMELON_SEEDS = "It's a melon seed.",
		CAVE_FERN = "It's a fern.",
		CHARCOAL = "It's a piece of burnt wood. We can use this as fuel.",
        CHESSPIECE_PAWN = 
        {
			GENERIC = "As warships, we're fated to an endless battle.",
		},
        CHESSPIECE_ROOK = 
        {
			GENERIC = "It's strong and prefers direct confrontation.",
			STRUGGLE = "The chess pieces... are moving!?",
		},
        CHESSPIECE_KNIGHT = 
        {
			GENERIC = "It's a horse-shaped chesspiece.",
			STRUGGLE = "The chess pieces... are moving!?",
		},
        CHESSPIECE_BISHOP = 
        {
			GENERIC = "It uses different approaches to solve conflict.",
			STRUGGLE = "The chess pieces... are moving!?",
		},
        CHESSPIECE_MUSE = 
        {
			GENERIC = "The strongest piece on the board.",
			--STRUGGLE = "Something's coming!!",
		},
        CHESSPIECE_FORMAL = 
        {
			GENERIC = "It's a very... kingly piece.",
		},
        CHESSPIECE_HORNUCOPIA = 
        {
			GENERIC = "A piece coupled with of a bunch of fruits.",
		},
        CHESSPIECE_PIPE = 
        {
			GENERIC = "I want to try that one day.",
		},
        CHESSJUNK1 = "A pile of broken chess pieces.",
        CHESSJUNK2 = "Another pile of broken chess pieces.",
        CHESSJUNK3 = "Even more broken chess pieces.",
		CHESTER = "A loyal buddy who will carry items for you.",
		CHESTER_EYEBONE =
		{
			GENERIC = "That's an ominous eye.",
			WAITING = "It's sleeping.",
		},
		COOKEDMANDRAKE = "Goodbye, screaming plant.",
		COOKEDMEAT = "Mmm, tasty.",
		COOKEDMONSTERMEAT = "I don't think it's a good idea to consume this.",
		COOKEDSMALLMEAT = "Slightly safer to consume than raw meat.",
		COOKPOT =
		{
			COOKING_LONG = "This is going to take a while.",
			COOKING_SHORT = "It's almost done.",
			DONE = "Horosho. It's ready to eat.",
			EMPTY = "I should cook something up.",
			BURNT = "It burnt down...",
		},
		CORN = "You eat it from the sides.",
		CORN_COOKED = "Cooked, and eaten from the sides.",
		CORN_SEEDS = "It's a corn seed.",
        CANARY =
		{
			GENERIC = "It's intensely vibrating its head.",
			HELD = "A small yellow canary.",
		},
        CANARY_POISONED = "It looks sick.",

		CRITTERLAB = "It's filled with all sorts of strange creatures.",
        CRITTER_GLOMLING = "It's a small winged fly.",
        CRITTER_DRAGONLING = "A small dragonfly.",
		CRITTER_LAMB = "Thankfully these ones don't shoot mucus at you.",
        CRITTER_PUPPY = "A loyal wolf. A fine pet.",
        CRITTER_KITTEN = "A cute, mischievous little cat raccoon.",
		CRITTER_PERDLING = "One day you'll be a Phoenix too, just like me.",
		
		CROW =
		{
			GENERIC = "Cute. Will it remember me?",
			HELD = "He doesn't look very happy.",
		},
		CUTGRASS = "Useful to keep things together.",
		CUTREEDS = "Useful as crafting materials.",
		CUTSTONE = "Some smooth stones, ready to be used.",
		DEADLYFEAST = "I don't think I should be eating this...",
		DEER =
		{
			GENERIC = "Does that deer not have eyes...?",
			ANTLER = "That's a strong-looking antler.",
		},
        DEER_ANTLER = "A strong antler.",
        DEER_GEMMED = "It seems like it's being controlled...!",
		DEERCLOPS = "It's enormous...!?",
		DEERCLOPS_EYEBALL = "A slimy eyeball from a giant beast.",
		EYEBRELLAHAT =	"The way it stares at you is somewhat uncomfortable...",
		DEPLETED_GRASS =
		{
			GENERIC = "It was grass.",
		},
		GOGGLESHAT = "Horosho. These look fancy.",
        DESERTHAT = "This'll keep the sand off my eyes.",
		DEVTOOL = "What's this energy?",
		DEVTOOL_NODEV = "I feel like I'm unable to wield this...",
		DIRTPILE = "It's a suspicious pile of dirt...",
		DIVININGROD =
		{
			COLD = "The signal is very faint.",
			GENERIC = "It's some kind of homing device.",
			HOT = "This thing's going crazy!",
			WARM = "I'm headed in the right direction.",
			WARMER = "Must be getting pretty close.",
		},
		DIVININGRODBASE =
		{
			GENERIC = "I wonder what it does.",
			READY = "It looks like it needs a large key.",
			UNLOCKED = "Now the machine can work!",
		},
		DIVININGRODSTART = "That rod looks useful!",
		DRAGONFLY = "Large enemy detected... It seems like it breathes fire...!",
		ARMORDRAGONFLY = "Hot scales, cooled down for use.",
		DRAGON_SCALES = "It's still a little warm.",
		DRAGONFLYCHEST = "A really secure box to store things in.",
		DRAGONFLYFURNACE = 
		{
			HAMMERED = "I don't think that was a good idea.",
			GENERIC = "Produces a lot of heat, but not much light.", --no gems
			NORMAL = "It's providing some warmth.", --one gem
			HIGH = "It's hot...!", --two gems
		},
        
        HUTCH = "It's a cute little anglerfish fellow.",
        HUTCH_FISHBOWL =
        {
            GENERIC = "Seems like the fish bollows me if I hold this.",
            WAITING = "Ah...",
        },
		LAVASPIT = 
		{
			HOT = "It's burning hot.",
			COOL = "It's significantly cooled down.",
		},
		LAVA_POND = "I don't think I should be too close.",
		LAVAE = "A small lava larva.",
		LAVAE_COCOON = "Cooled off and chilled out.",
		LAVAE_PET = 
		{
			STARVING = "It desperately needs some food...",
			HUNGRY = "It looks a little hungry.",
			CONTENT = "It seems content.",
			GENERIC = "I would pet it, but it's too hot.",
		},
		LAVAE_EGG = 
		{
			GENERIC = "I can feel a faint warmth coming from inside.",
		},
		LAVAE_EGG_CRACKED =
		{
			COLD = "It's lacking heat. Maybe move it closer to a fire?",
			COMFY = "The egg looks... content.",
		},
		LAVAE_TOOTH = "Seems like it follows me if I hold on to it.",

		DRAGONFRUIT = "A fruit with a cool-sounding name.",
		DRAGONFRUIT_COOKED = "The fruit still has a cool-sounding name, but now it's cooked.",
		DRAGONFRUIT_SEEDS = "It's a dragonfruit seed.",
		DRAGONPIE = "It's a very filling fruit pie.",
		DRUMSTICK = "No more gobbling for you.",
		DRUMSTICK_COOKED = "Fried gobbler. Very delicious.",
		DUG_BERRYBUSH = "Now it can be taken anywhere.",
		DUG_BERRYBUSH_JUICY = "We could move this closer to our base.",
		DUG_GRASS = "It can be moved somewhere else now.",
		DUG_MARSH_BUSH = "This needs to be planted.",
		DUG_SAPLING = "We can use this to plant trees.",
		DURIAN = "It's a sharp-smelling fruit.",
		DURIAN_COOKED = "The smell is worse now.",
		DURIAN_SEEDS = "It's a durian seed.",
		EARMUFFSHAT = "It helps your ears not freeze during the winter.",
		EGGPLANT = "I know Inazuma doesn't like these...",
		EGGPLANT_COOKED = "I don't think she likes it cooked, either.",
		EGGPLANT_SEEDS = "It's an eggplant seed.",
		
		ENDTABLE = 
		{
			BURNT = "It burnt down...",
			GENERIC = "A perfectly decorative table.",
			EMPTY = "It needs a little something to look better.",
			WILTED = "The light is dead.",
			FRESHLIGHT = "The light is warm and comfy.",
			OLDLIGHT = "We'll need to replace the flowers.", -- will be wilted soon, light radius will be very small at this point
		},
		DECIDUOUSTREE = 
		{
			BURNING = "All for charcoal.",
			BURNT = "It burnt down...",
			CHOPPED = "It's completely chopped down.",
			POISON = "Large enemy... detected? The tree is hostile!",
			GENERIC = "We need to deciduous if we need the wood or not.",
		},
		ACORN = "Maybe we can plant this somewhere.",
        ACORN_SAPLING = "It'll be a tree soon.",
		ACORN_COOKED = "Perfectly cooked.",
		BIRCHNUTDRAKE = "These small ones won't stop coming...!",
		EVERGREEN =
		{
			BURNING = "All for charcoal.",
			BURNT = "It burnt down...",
			CHOPPED = "It's completely chopped down.",
			GENERIC = "It's pine. No problem.",
		},
		EVERGREEN_SPARSE =
		{
			BURNING = "All for charcoal.",
			BURNT = "It burnt down...",
			CHOPPED = "It's completely chopped down.",
			GENERIC = "I don't think this one is special.",
		},
		TWIGGYTREE = 
		{
			BURNING = "All for charcoal.",
			BURNT = "It burnt down...",
			CHOPPED = "It's completely chopped down.",
			GENERIC = "We could use these for tools.",			
			DISEASED = "It looks... diseased.",
		},
		TWIGGY_NUT_SAPLING = "It's growing quite strongly.",
        TWIGGY_OLD = "That tree already lived for too long.",
		TWIGGY_NUT = "It's going to grow another tree soon.",
		EYEPLANT = "Those eyes are those of hungry ones...",
		INSPECTSELF = "I'm Hibiki. I'm also referred to as The Phoenix from my exploits.",
		FARMPLOT =
		{
			GENERIC = "We should plant some crops.",
			GROWING = "I feel strength growing from these plants.",
			NEEDSFERTILIZER = "I think it needs to be fertilized.",
			BURNT = "It burnt down...",
		},
		FEATHERHAT = "The name Phoenix isn't just for show.",
		FEATHER_CROW = "A crow feather.",
		FEATHER_ROBIN = "A redbird feather.",
		FEATHER_ROBIN_WINTER = "A snowbird feather.",
		FEATHER_CANARY = "A canary feather.",
		FEATHERPENCIL = "A sophisticated-looking pen.",
		FEM_PUPPET = "She's trapped...",
		FIREFLIES =
		{
			GENERIC = "Why do fireflies die so early?",
			HELD = "I'll keep you safe.",
		},
		FIREHOUND = "It's a dangerous one. Don't let it near the base!",
		FIREPIT =
		{
			EMBERS = "I should put something on the fire before it goes out.",
			GENERIC = "It's warm.",
			HIGH = "Thankfully, the fire's contained.",
			LOW = "The fire's getting a bit low.",
			NORMAL = "Nice and comfy.",
			OUT = "We can start it up again.",
		},
		COLDFIREPIT =
		{
			EMBERS = "I should put something on the fire before it goes out.",
			GENERIC = "Horosho. That's a beautiful-looking fire.",
			HIGH = "Thankfully, the fire's contained.",
			LOW = "The fire's getting a bit low.",
			NORMAL = "Nice and comfy.",
			OUT = "We can start it up again.",
		},
		FIRESTAFF = "This is the power of the Phoenix's flame.",
		FIRESUPPRESSOR = 
		{	
			ON = "It's activated. We should be safe from fires.",
			OFF = "It's turned off to save fuel.",
			LOWFUEL = "It's running out of fuel...",
		},

		FISH = "Horosho. A big catch.",
		FISHINGROD = "Useful to catch saury fish.",
		FISHSTICKS = "A nice snack to bring around.",
		FISHTACOS = "Crunchy, delicious, and fills me with satisfaction.",
		FISH_COOKED = "Grilled to perfection.",
		FLINT = "It's really useful to craft weapons.",
		FLOWER = 
		{
            GENERIC = "A small flower. It's pretty.",
            ROSE = "Roses have thorns.",
        },
        FLOWER_WITHERED = "I think it got too much sun.",
		FLOWERHAT = "It's pretty. I don't hate it.",
		FLOWER_EVIL = "This flower feels... off.",
		FOLIAGE = "Some leafy greens.",
		FOOTBALLHAT = "Horosho. This looks like strong head protection.",
        FOSSIL_PIECE = "A fossil piece? Maybe we should put them back together.",
        FOSSIL_STALKER =
        {
			GENERIC = "It's still missing a few pieces.",
			FUNNY = "I don't think... that's supposed to look like that.",
			COMPLETE = "Horosho. That was fun.",
        },
		STALKER = "It crawled out from the depths of hell...",
        STALKER_ATRIUM = "What a living nightmare...",
        STALKER_MINION = "They came in droves, but what are they doing...?",
        THURIBLE = "It attracts the darkness...",
        ATRIUM_OVERGROWTH = "Argh, my head... the memories are coming back...",
		FROG =
		{
			DEAD = "I guess you could say he croaked.",
			GENERIC = "They irritate you when you try to fish.",
			SLEEPING = "Stay down for a while.",
		},
		FROGGLEBUNWICH = "A very leggy sandwich.",
		FROGLEGS = "I've heard it tastes good.",
		FROGLEGS_COOKED = "Still doesn't look appetizing.",
		FRUITMEDLEY = "Fruity.",
		FURTUFT = "Black and white fur.", 
		GEARS = "A pile of mechanical parts.",
		GHOST = "A... ghost? Not as scary as everything else in this world.",
		GOLDENAXE = "It's an ornate axe.",
		GOLDENPICKAXE = "I'm not sure how golden tools are better than normal ones.",
		GOLDENPITCHFORK = "A fancy pitchfork.",
		GOLDENSHOVEL = "Digging holes with style.",
		GOLDNUGGET = "It's a shiny gold nugget.",
		GRASS =
		{
			BARREN = "It needs to be fertilized.",
			WITHERED = "It's not going to grow back in this heat.",
			BURNING = "We need to put it out...!",
			GENERIC = "It's just grass we can pick up.",
			PICKED = "It'll eventually grow back.",
			DISEASED = "It looks... diseased.",
			DISEASING = "I don't think it looks healthy.",
		},
		GRASSGEKKO = 
		{
			GENERIC = "It's a lizard covered in leaves.",	
			DISEASED = "It looks... diseased.",
		},
		GREEN_CAP = "It's a green mushroom.",
		GREEN_CAP_COOKED = "Does it have different effects now?",
		GREEN_MUSHROOM =
		{
			GENERIC = "It's a green mushroom.",
			INGROUND = "It's sleeping.",
			PICKED = "It'll grow back eventually.",
		},
		GUNPOWDER = "It's dangerous to keep this lying around.",
		HAMBAT = "Swinging around food as a weapon feels nice.",
		HAMMER = "Stop. Hammer time.",
		HEALINGSALVE = "The secret of the Phoenix is the timing of her repairs.",
		HEATROCK =
		{
			FROZEN = "It reminds me of the Russian cold.",
			COLD = "Holding this keeps me cool.",
			GENERIC = "It adapts to its surrounding temperature.",
			WARM = "It's warm... I don't hate it.",
			HOT = "It's toasty hot.",
		},
		HOME = "Someone is probably living here...",
		HOMESIGN =
		{
			GENERIC = "\"You are here\"... is what it says.",
            UNWRITTEN = "The sign is currently blank.",
			BURNT = "It burnt down...",
		},
		ARROWSIGN_POST =
		{
			GENERIC = "\"That way\"... is what it says.",
            UNWRITTEN = "The sign is currently blank.",
			BURNT = "It burnt down...",
		},
		ARROWSIGN_PANEL =
		{
			GENERIC = "\"That way\"... is what it says.",
            UNWRITTEN = "The sign is currently blank.",
			BURNT = "It burnt down...",
		},
		HONEY = "Can't be used to make Mega Potions.",
		HONEYCOMB = "A piece of a beehive.",
		HONEYHAM = "Sweet and savory.",
		HONEYNUGGETS = "Strangely, this tastes like... chicken.",
		HORN = "You can use this to attract beefalos.",
		HOUND = "Be careful. These hounds hunt in packs. Don't get swarmed.",
		HOUNDBONE = "This gives me the chills...",
		HOUNDMOUND = "Getting any closer would be a bad idea.",
		ICEBOX = "This will keep our food fresh.",
		ICEHAT = "That doesn't look very comfortable to wear...",
		ICEHOUND = "Enemy detected. Be careful of their cold breath.",
		INSANITYROCK =
		{
			ACTIVE = "It's sapping my sanity away...",
			INACTIVE = "It's some sort of a pyramid...?",
		},
		JAMMYPRESERVES = "Probably should have made a jar.",

		KABOBS = "Cheeki breeki.",
		KILLERBEE =
		{
			GENERIC = "It's a particularly dangerous bee...!",
			HELD = "It won't sting anyone like this.",
		},
		KNIGHT = "Riding on its high horse.",
		KOALEFANT_SUMMER = "Akatsuki? What was that about elephants?",
		KOALEFANT_WINTER = "Akatsuki? What was that about elephants?",
		KRAMPUS = "He's going after my things...!",
		KRAMPUS_SACK = "Eugh. It's slimy.",
		LEIF = "Enemy detected...!? Did it rise from one of the pine trees!?",
		LEIF_SPARSE = "Enemy detected...!? Did it rise from one of the pine trees!?",
		LIGHTER  = "It's someone's lighter...",
		LIGHTNING_ROD =
		{
			CHARGED = "Thankfully, that kept us safe.",
			GENERIC = "This should keep us safe from lightning strikes.",
		},
		LIGHTNINGGOAT = 
		{
			GENERIC = "It's a metallic-looking goat.",
			CHARGED = "I don't think it liked being struck by lightning.",
		},
		LIGHTNINGGOATHORN = "I feel like this horn attracts lightning.",
		GOATMILK = "Uncommon, but tasty.",
		LITTLE_WALRUS = "It'll grow up to be a murderer.",
		LIVINGLOG = "It's alive... somehow.",
		LOG =
		{
			BURNING = "All for charcoal.",
			GENERIC = "Food for the flame.",
		},
		LUCY = "That axe is... off, somehow.",
		LUREPLANT = "My gaze is getting pulled towards it...",
		LUREPLANTBULB = "We could use these to make plant meat.",
		MALE_PUPPET = "He's trapped...",

		MANDRAKE_ACTIVE = "I wish these things would stop following me.",
		MANDRAKE_PLANTED = "I've heard strange things about those plants...",
		MANDRAKE = "A mandrake root has strange powers.",

		MANDRAKESOUP = "Well, he won't be waking up again.",
		MANDRAKE_COOKED = "It doesn't seem so strange anymore.",
		MAPSCROLL = "A blank map. Not very useful right now.",
		MARBLE = "Fancy.",
		MARBLEBEAN = "Seems like you can use this to plant marble trees.",
		MARBLEBEAN_SAPLING = "It looks carved.",
        MARBLESHRUB = "Makes sense to me.",
		MARBLEPILLAR = "I think I could use that.",
		MARBLETREE = "I don't think an axe will cut it.",
		MARSH_BUSH =
		{
			BURNING = "We need to put it out...!",
			GENERIC = "It looks thorny.",
			PICKED = "That hurt.",
		},
		BURNT_MARSH_BUSH = "It burnt down...",
		MARSH_PLANT = "It's a marshy plant.",
		MARSH_TREE =
		{
			BURNING = "All for charcoal.",
			BURNT = "It burnt down...",
			CHOPPED = "It's all chopped down.",
			GENERIC = "Those are very sharp spikes.",
		},
		MAXWELL = "That person... Seems dangerous.",
		MAXWELLHEAD = "I still don't like him.",
		MAXWELLLIGHT = "Mysterious-looking lights.",
		MAXWELLLOCK = "This seems like a keyhole...",
		MAXWELLTHRONE = "That's a painful-looking throne.",
		MEAT = "A little raw, but some cooking can help with that.",
		MEATBALLS = "Balls of meat. Good snacks.",
		MEATRACK =
		{
			DONE = "Jerky time.",
			DRYING = "Meat takes a while to dry.",
			DRYINGINRAIN = "I don't think it will dry in this rain.",
			GENERIC = "We can dry some meat here.",
			BURNT = "It burnt down...",
		},
		MEAT_DRIED = "Jerky, but delicious.",
		MERM = "Fishmen...?",
		MERMHEAD = 
		{
			GENERIC = "It's very stinky...",
			BURNT = "It smells even worse burnt.",
		},
		MERMHOUSE = 
		{
			GENERIC = "Who would live here?",
			BURNT = "It burnt down...",
		},
		MINERHAT = "This will keep my hands free in the dark.",
		MONKEY = "It's a curious little guy.",
		MONKEYBARREL = "Did that just move?",
		MONSTERLASAGNA = "I don't think I would want to eat that.",
		FLOWERSALAD = "A bowl of salad.",
        ICECREAM = "Ice cream is always good when you feel down.",
        WATERMELONICLE = "It's a watermelon, but it's frozen.",
        TRAILMIX = "An assortment of healthy snacks.",
        HOTCHILI = "I can handle the hotness.",
        GUACAMOLE = "It's nice when turned into juice.",
		MONSTERMEAT = "I don't think I would want to eat that.",
		MONSTERMEAT_DRIED = "I don't think I should eat that, even as jerky.",
		MOOSE = "Large enemy detected...? What is that thing?",
		MOOSE_NESTING_GROUND = "It puts its babies there.",
		MOOSEEGG = "An egg from one of those giant moose things.",
		MOSSLING = "Giant ducklings. Seems deceptively dangerous.",
		FEATHERFAN = "I can to keep myself cool with this.",
        MINIFAN = "Somehow the breeze comes out the back twice as fast.",
		GOOSE_FEATHER = "Fluffy feathers.",
		STAFF_TORNADO = "Tornadoes of death.",
		MOSQUITO =
		{
			GENERIC = "Ugh. Mosquitoes.",
			HELD = "...Is that my blood?",
		},
		MOSQUITOSACK = "It's probably someone else's blood...",
		MOUND =
		{
			DUG = "I should probably feel bad about that.",
			GENERIC = "I wonder what's down there?",
		},
		NIGHTLIGHT = "It's powered by sanity...",
		NIGHTMAREFUEL = "Straight from my nightmares.",
		NIGHTSWORD = "Horosho. I feel power from this sword...",
		NITRE = "Would this boost our engines' power?",
		ONEMANBAND = "I've always wanted to start my own band.",
		OASISLAKE = "Always a refreshing sight in the desert.",
		PANDORASCHEST = "Some secrets are better kept hidden.",
		PANFLUTE = "Time for everyone to sleep.",
		PAPYRUS = "In case you needed to write a message.",
        WAXPAPER = "Used for important documents.",
		PENGUIN = "Horosho. Birds of the winter.",
		PERD = "That's a funny-looking bird. It's looking for berries.",
		PEROGIES = "Horosho. These turned out pretty good.",
		PETALS = "Everything will be okay...",
		PETALS_EVIL = "I'm getting bad vibes from these petals...",
		PHLEGM = "It's sticky... It won't come off.",
		PICKAXE = "Classic.",
		PIGGYBACK = "I feel kinda bad for that.",
		PIGHEAD = 
		{	
			GENERIC = "That's a little unsettling...",
			BURNT = "It burnt down...",
		},
		PIGHOUSE =
		{
			FULL = "Someone's definitely home. I can smell them inside.",
			GENERIC = "For being pigmen, they're surprisingly civilized.",
			LIGHTSOUT = "The lights are out, but something is definitely inside.",
			BURNT = "It completely burnt down...",
		},
		PIGKING = "A very dirty king.",
		PIGMAN =
		{
			DEAD = "...It's... dead...",
			FOLLOWER = "Come, comrade!",
			GENERIC = "Pigmen. They look weird.",
			GUARD = "He looks serious.",
			WEREPIG = "He's not friendly.",
		},
		PIGSKIN = "It's rubbery and smells like bacon.",
		PIGTENT = "It's a small pig tent.",
		PIGTORCH = "Looks a little comfy.",
		PINECONE = "We can plant it to make it a tree.",
        PINECONE_SAPLING = "It'll be a tree soon.",
        LUMPY_SAPLING = "How did this tree even reproduce?",
		PITCHFORK = "A lean, mean, farming tool.",
		PLANTMEAT = "Green, chlorophyll-laced meat.",
		PLANTMEAT_COOKED = "Surprisingly, it wasn't burned down.",
		PLANT_NORMAL =
		{
			GENERIC = "Leafy.",
			GROWING = "It's growing very slowly.",
			READY = "We can harvest it now.",
			WITHERED = "It was too hot...",
		},
		POMEGRANATE = "It's a weird-looking fruit.",
		POMEGRANATE_COOKED = "It's hot. Handle with care.",
		POMEGRANATE_SEEDS = "It's a pomegranate seed.",
		POND = "I can see small little fish. Cute.",
		POOP = "It's fertilizer.",
		--PORTABLECOOKPOT_ITEM = "Now we're cookin'!",
		FERTILIZER = "It's a big bucket of fertilizer.",
		PUMPKIN = "That's a big pumpkin.",
		PUMPKINCOOKIE = "It's a pretty... gourd cookie.",
		PUMPKIN_COOKED = "Roasted pumpkin.",
		PUMPKIN_LANTERN = "Good for the halloween spirit.",
		PUMPKIN_SEEDS = "It's a pumpkin seed.",
		PURPLEAMULET = "I'm hearing voices from it...",
		PURPLEGEM = "It's filled with all sorts of mysteries.",
		RABBIT =
		{
			GENERIC = "I hear they die of loneliness.",
			HELD = "There there. You won't be lonely anymore.",
		},
		RABBITHOLE = 
		{
			GENERIC = "I wonder where how deep the rabbit hole goes.",
			SPRING = "It seems to be closed.",
		},
		RAINOMETER = 
		{	
			GENERIC = "It measures cloudiness.",
			BURNT = "It burnt down...",
		},
		RAINCOAT = "It keeps myself dry.",
		RAINHAT = "It will help keeping the rain off my head.",
		RATATOUILLE = "Not to be confused with the movie.",
		RAZOR = "You could use this to shave something.",
		REDGEM = "It's radiating a small heat.",
		RED_CAP = "It's a red mushroom.",
		RED_CAP_COOKED = "Does it have different effects now?",
		RED_MUSHROOM =
		{
			GENERIC = "It's a red mushroom.",
			INGROUND = "It's sleeping.",
			PICKED = "I'll come back eventually.",
		},
		REEDS =
		{
			BURNING = "We need to put it out...!",
			GENERIC = "It's some swamp reeds.",
			PICKED = "It'll grow back eventually.",
		},
        RELIC = 
        {
            GENERIC = "These seem like ordinary household objects...",
            BROKEN = "They've fallen apart.",
        },
        RUINS_RUBBLE = "This looks like it could be fixed.",
        RUBBLE = "Just bits and pieces of rock.",
		RESEARCHLAB = 
		{	
			GENERIC = "We could build better, useful things with this.",
			BURNT = "It burnt down...",
		},
		RESEARCHLAB2 = 
		{
			GENERIC = "It's better than the previous one we had.",
			BURNT = "It burnt down...",
		},
		RESEARCHLAB3 = 
		{
			GENERIC = "For when you want to dabble into the dark arts.",
			BURNT = "It burnt down...",
		},
		RESEARCHLAB4 = 
		{
			GENERIC = "That's a funny name.",
			BURNT = "It burnt down...",
		},
		RESURRECTIONSTATUE = 
		{
			GENERIC = "An eerie statue. I'll come back here if I were to die.",
			BURNT = "It burnt down...",
		},		
		RESURRECTIONSTONE = "I can feel warmth coming from this stone.",
		ROBIN =
		{
			GENERIC = "Horosho. It's a red bird.",
			HELD = "I think he likes my pocket.",
		},
		ROBIN_WINTER =
		{
			GENERIC = "A beautiful blue bird. Winter has arrived.",
			HELD = "It's so soft...",
		},
		ROBOT_PUPPET = "They're trapped...",
		ROCK_LIGHT =
		{
			GENERIC = "A crusted over lava pit.",
			OUT = "Looks fragile.",
			LOW = "The lava's crusting over.",
			NORMAL = "Nice and comfy.",
		},
		CAVEIN_BOULDER =
        {
            GENERIC = "This fell from somewhere.",
            RAISED = "I don't think it's possible to reach it.",
        },
		ROCK = "It wouldn't fit in my pocket unless I break it apart.",
		PETRIFIED_TREE = "That's a very stiff tree.",
		ROCK_PETRIFIED_TREE = "That's a very stiff tree.",
		ROCK_PETRIFIED_TREE_OLD = "That's a very stiff tree.",
		ROCK_ICE = 
		{
			GENERIC = "A very isolated glacier.",
			MELTED = "Nothing useful until it freezes again.",
		},
		ROCK_ICE_MELTED = "Nothing useful until it freezes again.",
		ICE = "Useful for cooling drinks.",
		ROCKS = "I can build things with these.",
        ROOK = "Storm the castle.",
		ROPE = "Some short lengths of rope.",
		ROTTENEGG = "It's rotten...",
		ROYAL_JELLY = "Eating this will make anyone feel fresh.",
        JELLYBEAN = "One part jelly, one part bean.",
        SADDLE_BASIC = "This will allow me to ride an animal.",
        SADDLE_RACE = "This saddle feels... fast.",
        SADDLE_WAR = "This saddle makes my mount feel powerful.",
        SADDLEHORN = "This could take a saddle off.",
        SALTLICK = "Recommended to admirals who didn't get what they want.",
        BRUSH = "This will please the beefalo.",
		SANITYROCK =
		{
			ACTIVE = "That's a strange-looking rock...",
			INACTIVE = "Where did the rest of it go?",
		},
		SAPLING =
		{
			BURNING = "That's burning fast.",
			WITHERED = "It's dying...",
			GENERIC = "It's slowly growing.",
			PICKED = "I needed the twigs.",
			DISEASED = "It looks... diseased.",
			DISEASING = "Something isn't right...",
		},
   		SCARECROW = 
   		{
			GENERIC = "This will scare away the birds.",
			BURNING = "We need to put it out...!",
			BURNT = "It burnt down...",
   		},
   		SCULPTINGTABLE=
   		{
			EMPTY = "We can make stone sculptures with this.",
			BLOCK = "Ready for sculpting.",
			SCULPTURE = "Horosho.",
			BURNT = "It burnt down...",
   		},
        SCULPTURE_KNIGHTHEAD = "Where's the rest of it?",
		SCULPTURE_KNIGHTBODY = 
		{
			COVERED = "It's an odd marble statue.",
			UNCOVERED = "I guess he cracked under the pressure.",
			FINISHED = "At least it's back in one piece now.",
			READY = "Something's moving inside.",
		},
        SCULPTURE_BISHOPHEAD = "Is that a head?",
		SCULPTURE_BISHOPBODY = 
		{
			COVERED = "It looks old, but it feels new.",
			UNCOVERED = "There's a big piece missing.",
			FINISHED = "Now what?",
			READY = "Something's moving inside.",
		},
        SCULPTURE_ROOKNOSE = "Where did this come from?",
		SCULPTURE_ROOKBODY = 
		{
			COVERED = "It's some sort of marble statue.",
			UNCOVERED = "It's not in the best shape.",
			FINISHED = "All patched up.",
			READY = "Something's moving inside.",
		},
        GARGOYLE_HOUND = "Did that stone of the moon do this?",
        GARGOYLE_WEREPIG = "Horosho. Very lifelike.",
		SEEDS = "Plant seeds. It's a mystery what it'll grow into.",
		SEEDS_COOKED = "I don't think this will grow into anything.",
		SEWING_KIT = "Sewing, huh. Reminds me of the olden days.",
		SHOVEL = "Let's start digging, shall we?",
		SILK = "It's silk. Maybe it can be used as a string.",
		SKELETON = "...Rest in peace.",
		SCORCHED_SKELETON = "Spooky.",
		SKULLCHEST = "I'm not sure if I want to open it.",
		SMALLBIRD =
		{
			GENERIC = "That's a slightly less tall bird.",
			HUNGRY = "It looks hungry...",
			STARVING = "It must be starving. Let's feed it quick.",
		},
		SMALLMEAT = "It's a tiny chunk of meat.",
		SMALLMEAT_DRIED = "It's small but still jerky.",
		SPAT = "Beware of its sticky spit.",
		SPEAR = "Simple, but effective.",
		SPEAR_WATHGRITHR = "I feel great power radiating from this spear...!",
		WATHGRITHRHAT = "It's a sturdy-looking hat.",
		SPIDER =
		{
			DEAD = "That's one dead spider.",
			GENERIC = "Giant spiders.",
			SLEEPING = "It's sleeping. Maybe I can sneak past it.",
		},
		SPIDERDEN = "Sticky.",
		SPIDEREGGSACK = "I better move fast. These feel like they're gonna hatch.",
		SPIDERGLAND = "It feels like it can be used for medical purposes.",
		SPIDERHAT = "It full of goo, but this might help deal against the small ones.",
		SPIDERQUEEN = "Is that the queen...!? It's huge...",
		SPIDER_WARRIOR =
		{
			DEAD = "Dead.",
			GENERIC = "A dangerous looking spider.",
			SLEEPING = "I should keep my distance.",
		},
		SPOILED_FOOD = "At this point, it's completely inedible.",
        STAGEHAND =
        {
			AWAKE = "What could be under that table?",
			HIDING = "Something about that table bothers me...",
        },
        STATUE_MARBLE = 
        {
            GENERIC = "Aesthetic.",
            TYPE1 = "I don't want to end up like that.",
            TYPE2 = "I'm not sure if it can hold any water, being cracked like that.",
        },
		STATUEHARP = "I don't want to end up like that.",
		STATUEMAXWELL = "I still don't like this person...",
		STEELWOOL = "It's fluffy, but durable.",
		STINGER = "It's a really sharp bee stinger.",
		STRAWHAT = "A nice hat to prevent heatstroke.",
		STUFFEDEGGPLANT = "It's really stuffing.",
		--SUNKBOAT = "It's no use out there!",
		SWEATERVEST = "Horosho. Looking fashionable on survival.",
		REFLECTIVEVEST = "This will keep the sun away.",
		HAWAIIANSHIRT = "Perfect if you want a vacation, I suppose.",
		TAFFY = "Sweet and elastic.",
		TALLBIRD = "That's a... really tall bird.",
		TALLBIRDEGG = "I wonder if this will hatch.",
		TALLBIRDEGG_COOKED = "Horosho. That looks delicious.",
		TALLBIRDEGG_CRACKED =
		{
			COLD = "I wonder if it's too cold...",
			GENERIC = "Is it going to hatch any time soon?",
			HOT = "I think it needs to be colder.",
			LONG = "This may take a while to hatch.",
			SHORT = "Feels like it's almost going to hatch...!",
		},
		TALLBIRDNEST =
		{
			GENERIC = "That's an impressive-looking egg.",
			PICKED = "It's an empty nest.",
		},
		TEENBIRD =
		{
			GENERIC = "Horosho. Look at how much you've grown.",
			HUNGRY = "It looks really hungry.",
			STARVING = "I better feed it soon, otherwise...",
		},
		TELEPORTATO_BASE =
		{
			ACTIVE = "The teleporter is active. Let's go!",
			GENERIC = "Seems like you'll need to assemble the parts to make it work.",
			LOCKED = "Something is still missing...",
			PARTIAL = "It's almost done.",
		},
		TELEPORTATO_BOX = "This may control the polarity of the whole universe.",
		TELEPORTATO_CRANK = "Tough enough to handle the most intense experiments.",
		TELEPORTATO_POTATO = "This metal potato contains great and fearful power...",
		TELEPORTATO_RING = "A ring that could focus dimensional energies.",
		TELESTAFF = "That's an ominous-looking staff.",
		TENT = 
		{
			GENERIC = "I won't rest until I've finished everything.",
			BURNT = "It completely burned down...",
		},
		SIESTAHUT = 
		{
			GENERIC = "Maybe a short power nap wouldn't hurt.",
			BURNT = "It completely burned down...",
		},
		TENTACLE = "A tentacle. An Abyssal's favorite weapon...",
		TENTACLESPIKE = "Horosho. This will make enemies scream in pain.",
		TENTACLESPOTS = "What are these spots supposed to be?",
		TENTACLE_PILLAR = "A really large tentacle...",
        TENTACLE_PILLAR_HOLE = "It was where the large tentacles emerged.",
		TENTACLE_PILLAR_ARM = "A slightly smaller tentacle.",
		TENTACLE_GARDEN = "A tentacle...",
		TOPHAT = "A dapper-looking hat.",
		TORCH = "I'll need this to keep things visible at night.",
		TRANSISTOR = "Electricity is running through it...",
		TRAP = "I can use this to trap smaller animals.",
		TRAP_TEETH = "Brutal, but effective.",
		TRAP_TEETH_MAXWELL = "I won't want to step on that.",
		TREASURECHEST = 
		{
			GENERIC = "It's a chest you can store things in.",
			BURNT = "It burnt down...",
		},
		TREASURECHEST_TRAP = "How... convenient.",
		TREECLUMP = "That's quite annoying.",
		
		TRINKET_1 = "How does one melt marbles?", --Melted Marbles
		TRINKET_2 = "Makes funny noises.", --Fake Kazoo
		TRINKET_3 = "It won't un-knot itself.", --Gord's Knot
		TRINKET_4 = "A simple garden gnome. Unsettling.", --Gnome
		TRINKET_5 = "I don't think we'll be going on a trip in that tiny rocket ship.", --Toy Rocketship
		TRINKET_6 = "It won't be carrying any more electricity.", --Frazzled Wires
		TRINKET_7 = "I know a lot of kids played these back then.", --Ball and Cup
		TRINKET_8 = "This is no time to take a bath.", --Rubber Bung
		TRINKET_9 = "Zippers are cooler.", --Mismatched Buttons
		TRINKET_10 = "This probably belonged to an old man.", --Dentures
		TRINKET_11 = "Tell me lies, tell me sweet little lies...", --Lying Robot
		TRINKET_12 = "I should wrap it around Inazuma's legs.", --Dessicated Tentacle
		TRINKET_13 = "A female gnome. Very much unsettling.", --Gnomette
		TRINKET_14 = "I would have some tea, if I could.", --Leaky Teacup
		TRINKET_15 = "A bishop chesspiece.", --Pawn
		TRINKET_16 = "A bishop chesspiece.", --Pawn
		TRINKET_17 = "Some psychic probably messed around with it.", --Bent Spork
		TRINKET_18 = "There's nothing inside.", --Trojan Horse
		TRINKET_19 = "Some kids used to play these back in the day.", --Unbalanced Top
		TRINKET_20 = "I can scratch my own back just fine.", --Backscratcher
		TRINKET_21 = "Doesn't seem like this egg beater is good at its job.", --Egg Beater
		TRINKET_22 = "I sense a cat.", --Frayed Yarn
		TRINKET_23 = "What does this do...?", --Shoehorn
		TRINKET_24 = "This feels unnerving.", --Lucky Cat Jar
		TRINKET_25 = "It smells kind of stale.", --Air Unfreshener
		TRINKET_26 = "It's a cup, shaped like a potato...", --Potato Cup
		TRINKET_27 = "Would be nice, if we had a spare change of clothes.", --Coat Hanger
		TRINKET_28 = "A rook chesspiece.", --Rook
        TRINKET_29 = "A rook chesspiece.", --Rook
        TRINKET_30 = "A knight chesspiece.", --Knight
        TRINKET_31 = "A knight chesspiece.", --Knight
        TRINKET_32 = "I know someone who'd have a ball with this!", --Cubic Zirconia Ball
        TRINKET_33 = "I'm the queen of the spiders.", --Spider Ring
        TRINKET_34 = "Apparently, you can use this to make wishes.", --Monkey Paw
        TRINKET_35 = "Hard to find a good flask around here.", --Empty Elixir
		TRINKET_36 = "I might need these after all that candy.", --Faux fangs
		TRINKET_37 = "Would be useful to deal with vampires...", --Broken Stake

		HALLOWEENCANDY_1 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_2 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_3 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_4 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_5 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_6 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_7 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_8 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_9 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_10 = "We used to go trick or treating to get these...",
        HALLOWEENCANDY_11 = "We used to go trick or treating to get these...",
        CANDYBAG = "This can hold a lot of candy.",
		
		DRAGONHEADHAT = "Horosho. We'll need someone powerful to lead.",
        DRAGONBODYHAT = "The body is where the vital components lie.",
        DRAGONTAILHAT = "I can protect the rear side.",
        PERDSHRINE =
        {
            GENERIC = "Shall we put some offerings down?",
            EMPTY = "I'd need to plant something down here.",
            BURNT = "It burnt down...",
        },
        REDLANTERN = "Red is a powerful color.",
        LUCKY_GOLDNUGGET = "Horosho. I feel lucky.",
        FIRECRACKERS = "It makes crackly sounds when ignited.",
        PERDFAN = "I feel large amounts of power from this fan...",
        REDPOUCH = "Seems like something is inside...",

		BISHOP_CHARGE_HIT = "Ugh...!",
		TRUNKVEST_SUMMER = "It's surprisingly casual.",
		TRUNKVEST_WINTER = "It's surprisingly casual... in winter.",
		TRUNK_COOKED = "It's really crispy.",
		TRUNK_SUMMER = "A light breezy trunk.",
		TRUNK_WINTER = "A thick, hairy trunk.",
		TUMBLEWEED = "I've seen it roll all over desert settings.",
		TURKEYDINNER = "Horosho. That looks delicious.",
		TWIGS = "It's a bunch of small twigs.",
		UMBRELLA = "It keeps the water off my head.",
		GRASS_UMBRELLA = "Even as a ship, taking too much water would be a bad idea.",
		UNIMPLEMENTED = "It doesn't look finished. It could be dangerous.",
		WAFFLES = "Crispy and sweet waffles. Needs more syrup.",
		WALL_HAY = 
		{	
			GENERIC = "Not a very good idea against fire.",
			BURNT = "It burnt down...",
		},
		WALL_HAY_ITEM = "If it works, it works.",
		WALL_STONE = "It's a strong wall.",
		WALL_STONE_ITEM = "It's an integral part in base building.",
		WALL_RUINS = "It won't be ruined so easily.",
		WALL_RUINS_ITEM = "It's surprisingly strong for an ancient piece.",
		WALL_WOOD = 
		{
			GENERIC = "Keeps wild animals away, but not wildfires.",
			BURNT = "It burnt down...",
		},
		WALL_WOOD_ITEM = "It's a bunch of wood bundled together.",
		WALL_MOONROCK = "Goodbye, moonmen.",
		WALL_MOONROCK_ITEM = "It's really tough, but really light.",
		FENCE = "It's a normal wood fence.",
        FENCE_ITEM = "We could make a fence with this.",
        FENCE_GATE = "It doesn't have to be fencey.",
        FENCE_GATE_ITEM = "We could make a gate with this.",
		WALRUS = "I have a bad feeling about those walruses...",
		WALRUSHAT = "It's really warm and fuzzy.",
		WALRUS_CAMP =
		{
			EMPTY = "Someone was camping here before.",
			GENERIC = "Seems like it's really comfy inside.",
		},
		WALRUS_TUSK = "These are sharp. They'll probably be useful for weapons.",
		WARDROBE = 
		{
			GENERIC = "I don't think most of these outfits fit me...",
            BURNING = "We have to put it out!",
			BURNT = "It burnt down...",
		},
		WARG = "That's a dangerous-looking big wolf.",
		WASPHIVE = "It's best not to anger those bees.",
		WATERBALLOON = "This will be useful for fires.",
		WATERMELON = "It's full of juices..",
		WATERMELON_COOKED = "It's still juicy, surprisingly.",
		WATERMELONHAT = "The juice is still running down...",
		WAXWELLJOURNAL = "What's this?",
		WETGOOP = "I failed...",
        WHIP = "I want to feel like a vampire hunter.",
		WINTERHAT = "It's really useful to ward off the Russian cold.",
		WINTEROMETER = 
		{
			GENERIC = "You can see how cold it is.",
			BURNT = "It burnt down...",
		},

        WINTER_TREE =
        {
            BURNT = "It burnt down...",
            BURNING = "We have to put it out...!",
            CANDECORATE = "Merry Christmas.",
            YOUNG = "It's growing up quite nicely.",
        },
		WINTER_TREESTAND = 
		{
			GENERIC = "We'll need to grow a pine tree.",
            BURNT = "It burnt down...",
		},
        WINTER_ORNAMENT = "It's something you'll need for christmas.",
        WINTER_ORNAMENTLIGHT = "All it needs now is some electricity.",
        WINTER_ORNAMENTBOSS = "Horosho. That's an impressive addition to the tree.",

        WINTER_FOOD1 = "It's a sweet gingerbread cookie.", --gingerbread cookie
        WINTER_FOOD2 = "A little sweet snack for the holidays.", --sugar cookie
        WINTER_FOOD3 = "It's too hard to chew off...", --candy cane
        WINTER_FOOD4 = "A fruitcake. Very fruity.", --fruitcake
        WINTER_FOOD5 = "It's a log-shaped cake.", --yule log cake
        WINTER_FOOD6 = "Horosho. It's a delicious-looking pudding.", --plum pudding
        WINTER_FOOD7 = "It's not really vodka, but it's close enough.", --apple cider
        WINTER_FOOD8 = "It's warm. Good when you're feeling cold outside.", --hot cocoa
        WINTER_FOOD9 = "It's a sweet mixture of milk, sugar, and eggs.", --eggnog

        KLAUS = "Large enemy detected... be careful!",
        KLAUS_SACK = "What's in this sack...?",
		KLAUSSACKKEY = "A fancy key resembling a deer antler.",
		WORMHOLE =
		{
			GENERIC = "It looks dangerous...",
			OPEN = "I think it's a bad idea to jump in...",
		},
		WORMHOLE_LIMITED = "That's a diseased-looking wormhole...",
		ACCOMPLISHMENT_SHRINE = "Achievements? That sounds nice.",        
		LIVINGTREE = "I feel like I'm being watched...",
		ICESTAFF = "With this, I feel like I command the winters of Russia.",
		REVIVER = "If I could revive my sisters with this...",
		SHADOWHEART = "This heart, it's making me uneasy...",
		ATRIUM_RUBBLE = 
        {
			LINE_1 = "There are pictures of hungry people here.",
			LINE_2 = "The engravings are too worn out.",
			LINE_3 = "Darkness is approaching the city...?",
			LINE_4 = "The people here are... shedding their skins.",
			LINE_5 = "This picture reminds me of the world we came from...",
		},
        ATRIUM_STATUE = "There's something really off about that statue.",
        ATRIUM_LIGHT = 
        {
			ON = "This light makes me feel... uneasy.",
			OFF = "There's no power running through it.",
		},
        ATRIUM_GATE =
        {
			ON = "Looks like the gate is open now.",
			OFF = "What could this be about?",
			CHARGING = "It's charging up power.",
			DESTABILIZING = "The gate... it's destabilizing?",
			COOLDOWN = "It's still cooling down.",
        },
        ATRIUM_KEY = "This looks like a key of some sorts...",
		LIFEINJECTOR = "Helps nurse the recently revived to better health.",
		SKELETON_PLAYER =
		{
			MALE = "Seems like %s was killed by %s...",
			FEMALE = "Seems like %s was killed by %s...",
			ROBOT = "Seems like %s was killed by %s...",
			DEFAULT = "Seems like %s was killed by %s...",
		},
		HUMANMEAT = "Human flesh...? Ugh...",
		HUMANMEAT_COOKED = "It's cooked, but eating it is still out of the question.",
		HUMANMEAT_DRIED = "It's all jerky, but there's an even bigger jerk.",
		ROCK_MOON = "That rock came from the moon.",
		MOONROCKNUGGET = "That rock came from the moon.",
		MOONROCKCRATER = "There seems to be something you can stick inside it...",

        REDMOONEYE = "This red marker will help us navigate the way.",
        PURPLEMOONEYE = "This purple marker will help us navigate the way.",
        GREENMOONEYE = "This green marker will help us navigate the way.",
        ORANGEMOONEYE = "This orange marker will help us navigate the way.",
        YELLOWMOONEYE = "This yellow marker will help us navigate the way.",
        BLUEMOONEYE = "This blue marker will help us navigate the way.",
        
	},
	DESCRIBE_GENERIC = "I can't seem to describe it...",
	DESCRIBE_TOODARK = "It's too dark...",
	DESCRIBE_SMOLDERING = "Careful, it's going to catch fire soon.",
	EAT_FOOD =
	{
		TALLBIRDEGG_CRACKED = "Horosho.",
	},
}
