PrefabFiles = {
	"hibiki",
	"hibiki_none",
}

Assets = {
    Asset( "IMAGE", "images/saveslot_portraits/hibiki.tex" ),
    Asset( "ATLAS", "images/saveslot_portraits/hibiki.xml" ),

    Asset( "IMAGE", "images/selectscreen_portraits/hibiki.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/hibiki.xml" ),
	
    Asset( "IMAGE", "images/selectscreen_portraits/hibiki_silho.tex" ),
    Asset( "ATLAS", "images/selectscreen_portraits/hibiki_silho.xml" ),

    Asset( "IMAGE", "bigportraits/hibiki.tex" ),
    Asset( "ATLAS", "bigportraits/hibiki.xml" ),
	
	Asset( "IMAGE", "images/map_icons/hibiki.tex" ),
	Asset( "ATLAS", "images/map_icons/hibiki.xml" ),
	
	Asset( "IMAGE", "images/map_icons/verniy.tex" ),
	Asset( "ATLAS", "images/map_icons/verniy.xml" ),
	
	Asset( "IMAGE", "images/map_icons/hibiki_gangut.tex" ),
	Asset( "ATLAS", "images/map_icons/hibiki_gangut.xml" ),
	
	Asset( "IMAGE", "images/map_icons/verniy_gangut.tex" ),
	Asset( "ATLAS", "images/map_icons/verniy_gangut.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_hibiki.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_hibiki.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_hibiki_gangut.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_hibiki_gangut.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_ghost_hibiki.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_ghost_hibiki.xml" ),
	
	Asset( "IMAGE", "images/avatars/avatar_ghost_hibiki_gangut.tex" ),
    Asset( "ATLAS", "images/avatars/avatar_ghost_hibiki_gangut.xml" ),
	
	Asset( "IMAGE", "images/avatars/self_inspect_hibiki.tex" ),
    Asset( "ATLAS", "images/avatars/self_inspect_hibiki.xml" ),
	
	Asset( "IMAGE", "images/avatars/self_inspect_hibiki_gangut.tex" ),
    Asset( "ATLAS", "images/avatars/self_inspect_hibiki_gangut.xml" ),
	
	Asset( "IMAGE", "images/names_hibiki.tex" ),
    Asset( "ATLAS", "images/names_hibiki.xml" ),
	
    Asset( "IMAGE", "bigportraits/hibiki_none.tex" ),
    Asset( "ATLAS", "bigportraits/hibiki_none.xml" ),
	
	Asset( "IMAGE", "bigportraits/hibiki_gangut.tex" ),
    Asset( "ATLAS", "bigportraits/hibiki_gangut.xml" ),

}

local require = GLOBAL.require
local STRINGS = GLOBAL.STRINGS

GLOBAL.TUNING.HIBIKI = {}
if GetModConfigData("General Winter") == "Off" then
	GLOBAL.TUNING.HIBIKI.GENERAL_WINTER = false
else
	GLOBAL.TUNING.HIBIKI.GENERAL_WINTER = true
end

if GetModConfigData("Survivor's Guilt") == "Off" then
	GLOBAL.TUNING.HIBIKI.SURVIVOR_GUILT = false
else
	GLOBAL.TUNING.HIBIKI.SURVIVOR_GUILT = true
end

if GetModConfigData("Phoenix's Resilience") == "Off" then
	GLOBAL.TUNING.HIBIKI.PHOENIX_RESILIENCE = false
else
	GLOBAL.TUNING.HIBIKI.PHOENIX_RESILIENCE = true
end

if GetModConfigData("Trustworthy") == "Off" then
	GLOBAL.TUNING.HIBIKI.TRUSTWORTHY = false
else
	GLOBAL.TUNING.HIBIKI.TRUSTWORTHY = true
end

if GetModConfigData("Death Lv Drain (Trust)") == "Off" then
	GLOBAL.TUNING.HIBIKI.TRUSTWORTHYHARDMODE = false
else
	GLOBAL.TUNING.HIBIKI.TRUSTWORTHYHARDMODE = true
end

GLOBAL.TUNING.HIBIKI.BASEHUNGER = 100
GLOBAL.TUNING.HIBIKI.MAXHUNGER = 150

GLOBAL.TUNING.HIBIKI.BASESANITY = 100
GLOBAL.TUNING.HIBIKI.MAXSANITY = 100

GLOBAL.TUNING.HIBIKI.BASEHEALTH = 150
GLOBAL.TUNING.HIBIKI.MAXHEALTH = 200

-- The character select screen lines
STRINGS.CHARACTER_TITLES.hibiki = "Undying Phoenix"
STRINGS.CHARACTER_NAMES.hibiki = "Hibiki"
STRINGS.CHARACTER_DESCRIPTIONS.hibiki = "*General Winter\n*Survivor's Guilt\n*Phoenix's Resilience"
STRINGS.CHARACTER_QUOTES.hibiki = "\"The name of Phoenix isn't just for show.\""

-- Custom speech strings
STRINGS.CHARACTERS.HIBIKI = require "speech_hibikiv2"

-- The character's name as appears in-game 
STRINGS.NAMES.HIBIKI = "Hibiki"

AddMinimapAtlas("images/map_icons/hibiki.xml")
AddMinimapAtlas("images/map_icons/verniy.xml")
AddMinimapAtlas("images/map_icons/hibiki_gangut.xml")
AddMinimapAtlas("images/map_icons/verniy_gangut.xml")

-- Add mod character to mod character list. Also specify a gender. Possible genders are MALE, FEMALE, ROBOT, NEUTRAL, and PLURAL.
AddModCharacter("hibiki", "FEMALE")

modimport("scripts/skins_hibiki.lua")