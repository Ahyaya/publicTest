-- This information tells other players more about the mod
name = "DD Hibiki"
description = "Destroyer Hibiki \nfrom Kantai Collection \n[Version: 1.5.0b] \n\n[Traits/Perks]\nGeneral Winter: High cold resistance from being in the Russian Navy. \nSurvivor's Guilt: 10% more sanity loss when alone, gains sanity when near other players. \nPhoenix's Resilience: Starts with 200 health, takes 10% less damage."
author = "RaythalosM"
version = "1.5.0b" -- This is the version of the template. Change it to your own number.

-- This is the URL name of the mod's thread on the forum; the part after the ? and before the first & in the url
forumthread = "/files/file/950-extended-sample-character/"


-- This lets other players know if your mod is out of date, update it to match the current version in the game
api_version = 10

-- Compatible with Don't Starve Together
dst_compatible = true

-- Not compatible with Don't Starve
dont_starve_compatible = false
reign_of_giants_compatible = false

-- Character mods need this set to true
all_clients_require_mod = true 

icon_atlas = "modicon.xml"
icon = "modicon.tex"

-- The mod's tags displayed on the server list
server_filter_tags = {
"character",
}

-- Modded character menu compatibility
menu_assets = {
    characters = {
        hibiki = { gender = "FEMALE", skins = {}, nopuppet = true }
    }
}

-- Configuration options
configuration_options = {
	{
        name = "General Winter",
        label = "General Winter",
        options = 
        {
            {description = "On", data = "On"},
            {description = "Off", data = "Off"},
        },
        default = "On"
    },
	
    {
        name = "Survivor's Guilt",
        label = "Survivor's Guilt",
        options = 
        {
            {description = "On", data = "On"},
            {description = "Off", data = "Off"},
        },
        default = "On"
    },
	
	{
        name = "Phoenix's Resilience",
        label = "Phoenix's Resilience",
        options = 
        {
            {description = "On", data = "On"},
            {description = "Off", data = "Off"},
        },
        default = "On"
    },
	
	{
        name = "Trustworthy",
        label = "Trustworthy",
        options = 
        {
            {description = "On", data = "On"},
            {description = "Off", data = "Off"},
        },
        default = "On"
    },
	
	{
        name = "Death Lv Drain (Trust)",
        label = "Death Lv Drain (Trust)",
        options = 
        {
            {description = "Easy Mode", data = "Off"},
            {description = "Hard Mode", data = "On"},
        },
        default = "Off"
    },
}