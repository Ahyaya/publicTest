# Hound Attack

A Don't Stave Together mod that tells you when the next hound attack will happen

#### Steam Workshop

[Click Here](http://steamcommunity.com/sharedfiles/filedetails/?id=770901818) 

### Changelog

`2016/11/30` Fixed game crash when cave is enabled

`2016/09/27` Upload