_G = GLOBAL
local STRINGS = _G.STRINGS
local ActionHandler = _G.ActionHandler

local DFV_LANG = GetModConfigData("DFV_Language")

PrefabFiles = {
    "dug_cave_banana_tree", 
    "dug_lichen", 
    "dug_cactus", 
    "dug_flower_cave", 
    "dug_reeds", 
    "dug_shrooms",
    "dug_oasis_cactus",
    "dug_wormlight_plant",
}

if DFV_LANG == "EN" then
	STRINGS.NAMES.DUG_CACTUS = "Cactus Root"
	STRINGS.NAMES.DUG_OASIS_CACTUS = "Cactus Oasis Root"
	STRINGS.NAMES.DUG_LICHEN = "Cave Lichen Root"
	STRINGS.NAMES.DUG_CAVE_BANANA_TREE = "Cave Banana Tree Root"
	STRINGS.NAMES.DUG_REEDS = "Reed Root"
	STRINGS.NAMES.DUG_FLOWER_CAVE = "Light Flower Root"
	STRINGS.NAMES.DUG_FLOWER_CAVE_DOUBLE = "Light Flower Root"
	STRINGS.NAMES.DUG_FLOWER_CAVE_TRIPLE = "Light Flower Root"
	STRINGS.NAMES.DUG_RED_MUSHROOM = "Red Mushroom Root"
	STRINGS.NAMES.DUG_BLUE_MUSHROOM = "Blue Mushroom Root"
	STRINGS.NAMES.DUG_GREEN_MUSHROOM = "Green Mushroom Root"
	STRINGS.NAMES.DUG_WORMLIGHT_PLANT = "wormlight plant Root"

	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_RED_MUSHROOM = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_BLUE_MUSHROOM = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_GREEN_MUSHROOM = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_CACTUS = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_OASIS_CACTUS = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_LICHEN = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_CAVE_BANANA_TREE = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_REEDS = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_FLOWER_CAVE = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_FLOWER_CAVE_DOUBLE = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_FLOWER_CAVE_TRIPLE = "I should bring it to a better place."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_WORMLIGHT_PLANT = "I should bring it to a better place."

elseif DFV_LANG == "CN" then
	STRINGS.NAMES.DUG_CACTUS = "仙人球根"
	STRINGS.NAMES.DUG_OASIS_CACTUS = "仙人掌根"
	STRINGS.NAMES.DUG_LICHEN = "洞穴苔藓根"
	STRINGS.NAMES.DUG_CAVE_BANANA_TREE = "洞穴香蕉树根"
	STRINGS.NAMES.DUG_REEDS = "芦苇根"
	STRINGS.NAMES.DUG_FLOWER_CAVE = "荧光花丛"
	STRINGS.NAMES.DUG_FLOWER_CAVE_DOUBLE = "荧光花丛"
	STRINGS.NAMES.DUG_FLOWER_CAVE_TRIPLE = "荧光花丛"
	STRINGS.NAMES.DUG_RED_MUSHROOM = "红蘑菇根"
	STRINGS.NAMES.DUG_BLUE_MUSHROOM = "蓝蘑菇根"
	STRINGS.NAMES.DUG_GREEN_MUSHROOM = "绿蘑菇根"
	STRINGS.NAMES.DUG_WORMLIGHT_PLANT = "发光浆果根"

	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_RED_MUSHROOM = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_BLUE_MUSHROOM = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_GREEN_MUSHROOM = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_CACTUS = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_OASIS_CACTUS = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_LICHEN = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_CAVE_BANANA_TREE = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_REEDS = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_FLOWER_CAVE = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_FLOWER_CAVE_DOUBLE = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_FLOWER_CAVE_TRIPLE = "我应该把它带到更有用的地方."
	STRINGS.CHARACTERS.GENERIC.DESCRIBE.DUG_WORMLIGHT_PLANT = "我应该把它带到更合适的地方."
end


if _G.TheNet and _G.TheNet:GetIsServer() then

	--------------------------------Crop--------------------------------------
	function GrowerComponentPostInit(inst)
		inst.RemoveCrop = function(self ,crop)
		    crop:Remove()
		    self.crops[crop] = nil 
		    for k,v in pairs(self.crops) do
		        return
		    end
		     
		    self.isempty = true
		    self.inst:RemoveTag("NOCLICK")
		    self.cycles_left = self.cycles_left - 1
		     
		    if self.setfertility then
		        self.setfertility(self.inst, self:GetFertilePercent())
		    end
		end
	end


	--------------------------------DigUp--------------------------------
	local function DigUp(inst)
		local pt = Point(inst.Transform:GetWorldPosition())
		inst:Remove()
		if inst.components.diggable then
			inst.components.diggable:Collect(inst)
		end
		if inst.components.pickable and inst.components.pickable:CanBePicked() then
			--------------------switch func------------------
			local key = inst.prefab
			local switch = {  
			    ["lichen"] = function(inst)  
			    	inst.components.lootdropper:SpawnLootPrefab("cutlichen", pt) 
			    end, 

			    ["cave_banana_tree"] = function(inst)  
			    	inst.components.lootdropper:SpawnLootPrefab("cave_banana", pt) 
			    end, 

			    ["cactus"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("cactus_meat", pt)
			        if inst.has_flower then
					    inst.components.lootdropper:SpawnLootPrefab("cactus_flower", pt)
					end   
			    end,

			    ["oasis_cactus"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("cactus_meat", pt)
			        if inst.has_flower then
					    inst.components.lootdropper:SpawnLootPrefab("cactus_flower", pt)
					end   
			    end,

			    ["reeds"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("cutreeds", pt)  
			    end,

			    ["flower_cave"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("lightbulb", pt)  
			    end,

			    ["flower_cave_double"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("lightbulb", pt)
			        inst.components.lootdropper:SpawnLootPrefab("lightbulb", pt)  
			    end,

			    ["flower_cave_triple"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("lightbulb", pt)
			        inst.components.lootdropper:SpawnLootPrefab("lightbulb", pt)
			        inst.components.lootdropper:SpawnLootPrefab("lightbulb", pt)  
			    end,

			    ["red_mushroom"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("red_cap", pt)  
			    end,

			    ["green_mushroom"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("green_cap", pt)  
			    end,

			    ["blue_mushroom"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("blue_cap", pt)  
			    end,

			    ["wormlight_plant"] = function(inst)  
			        inst.components.lootdropper:SpawnLootPrefab("wormlight_lesser", pt)  
			    end,
			} 

			local fswitch = switch[key]
			fswitch(inst)
			--------------------------------
		end
	end
	  	

	--------------------------------Diggable--------------------------------
	local function ontransplantfn(inst)
		inst.components.pickable:MakeEmpty()
		print(inst.name)
	end

	local function diggablefn(inst)
		if not inst.components.lootdropper then
		    inst:AddComponent("lootdropper")
		end

		if not inst.components.workable then
			inst:AddComponent("workable") 
			inst.components.workable:SetWorkAction(_G.ACTIONS.DIG) 
		    inst.components.workable:SetOnFinishCallback(DigUp)
		    inst.components.workable:SetWorkLeft(1)
		end

		if inst.prefab == "cave_banana_tree" then
			inst.components.workable:SetWorkAction(_G.ACTIONS.DIG)	
		    inst.components.workable:SetOnFinishCallback(DigUp)
		    inst.components.workable:SetWorkLeft(1)
		elseif inst.prefab == "red_mushroom" or "green_mushroom" or "blue_mushroom" then
			inst.components.workable:SetOnFinishCallback(DigUp)
		    inst.components.workable:SetWorkLeft(1)
		end

		inst.components.pickable.ontransplantfn = ontransplantfn

		inst:AddComponent("diggable")	
		inst.components.diggable:SetUp("dug_"..inst.prefab)	    
	end


	AddComponentPostInit("grower", GrowerComponentPostInit)
	AddPrefabPostInit("cave_banana_tree", diggablefn)
	AddPrefabPostInit("lichen", diggablefn)
	AddPrefabPostInit("cactus", diggablefn)
	AddPrefabPostInit("oasis_cactus", diggablefn)
	AddPrefabPostInit("flower_cave", diggablefn)
	AddPrefabPostInit("flower_cave_double", diggablefn)
	AddPrefabPostInit("flower_cave_triple", diggablefn)
	AddPrefabPostInit("reeds", diggablefn)
	AddPrefabPostInit("red_mushroom", diggablefn)
	AddPrefabPostInit("green_mushroom", diggablefn)
	AddPrefabPostInit("blue_mushroom", diggablefn)
	AddPrefabPostInit("wormlight_plant", diggablefn)

end
