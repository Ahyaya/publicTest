name = "Adshovel"
author = "fais0n"
version = "1.6"
description = "v"..version.."\ntransplant reeds, cactus and so on."
forumthread = ""

api_version = 6
api_version_dst = 10


all_clients_require_mod = true
client_only_mod = false


dont_starve_compatible = true
reign_of_giants_compatible = true
dst_compatible = true
shipwrecked_compatible = true


server_filter_tags = {"adshovel"}

icon_atlas = "adshovel.xml"
icon = "adshovel.tex"



configuration_options =
{
	{
		name = "DFV_Language",
		label = "Language",
		options = 	{
						{description = "English", data = "EN"},
						{description = "中文", data = "CN"},
				 	},

		default = "EN",
	},
}