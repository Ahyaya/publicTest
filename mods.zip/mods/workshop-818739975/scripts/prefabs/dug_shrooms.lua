
local function createshroom(data)

    local assets = 
    {
	Asset("ANIM", "anim/dropped.zip"),
        Asset("ATLAS", "images/inventoryimages/dug_"..data.animname.."_mushroom.xml"),
        Asset("IMAGE", "images/inventoryimages/dug_"..data.animname.."_mushroom.tex"),
    }

    local notags = {'NOBLOCK', 'player', 'FX'}

            
          
    local function ondeploy(inst, pt)
    	local tree = SpawnPrefab(data.name) 
    	if tree then 
    		tree.Transform:SetPosition(pt.x, pt.y, pt.z)
            tree.SoundEmitter:PlaySound("dontstarve/common/mushroom_up")
    		inst.components.stackable:Get():Remove()
    		tree.components.pickable:OnTransplant()
    	end 
    end


    local function fn(Sim)
        local inst = CreateEntity()
        inst.entity:AddTransform()
        inst.entity:AddAnimState()
        inst.entity:AddNetwork()

        MakeInventoryPhysics(inst)
        
        inst.AnimState:SetBank("dropped")
        inst.AnimState:SetBuild("dropped")
        inst.AnimState:PlayAnimation("dropped_"..data.animname.."_mushroom")

        if not TheWorld.ismastersim then
            return inst
        end

        inst.entity:SetPristine()

        inst:AddComponent("deployable")
        inst.components.deployable.mode = DEPLOYMODE.PLANT
        inst.components.deployable.ondeploy = ondeploy
        inst.components.deployable.min_spacing = 2
        
        inst:AddComponent("stackable")
        inst.components.stackable.maxsize = TUNING.STACK_SIZE_SMALLITEM

        inst:AddComponent("inspectable")
        
        MakeSmallBurnable(inst, TUNING.TINY_BURNTIME)
        MakeSmallPropagator(inst)
        inst:AddComponent("inventoryitem")
        inst.components.inventoryitem.atlasname = "images/inventoryimages/dug_"..data.animname.."_mushroom.xml"
        
        return inst
    end

    return Prefab( "common/inventory/dug_"..data.animname.."_mushroom", fn, assets)
end

local data = { {name = "red_mushroom", animname="red"}, 
               {name = "green_mushroom", animname="green"},
               {name = "blue_mushroom", animname="blue"}
           }
local prefabs = {}

for k,v in pairs(data) do
    local shroom = createshroom(v)
    table.insert(prefabs, shroom)
    table.insert(prefabs, MakePlacer( "common/dug_"..v.animname.."_mushroom_placer", "mushrooms", "mushrooms", "inground" ))
end

return unpack(prefabs) 
