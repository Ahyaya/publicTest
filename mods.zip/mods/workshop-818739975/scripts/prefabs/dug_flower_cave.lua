
local function createflower(data)

    local assets = 
    {
        Asset("ANIM", "anim/dropped.zip"),
        Asset("ATLAS", "images/inventoryimages/dug_flower_cave"..data.animname..".xml"),
        Asset("IMAGE", "images/inventoryimages/dug_flower_cave"..data.animname..".tex"),
    }

    local function ondeploy(inst, pt)
        local tree = SpawnPrefab(data.name) 
        if tree then 
            tree.Transform:SetPosition(pt.x, pt.y, pt.z) 
            inst.components.stackable:Get():Remove()
            tree.components.pickable:OnTransplant()
            tree.SoundEmitter:PlaySound("dontstarve/wilson/plant_tree")
        end 
    end


    local function fn(Sim)
        local inst = CreateEntity()
        inst.entity:AddTransform()
        inst.entity:AddAnimState()
        inst.entity:AddNetwork()

        MakeInventoryPhysics(inst)
        
        inst.AnimState:SetBank("dropped")
        inst.AnimState:SetBuild("dropped")
        inst.AnimState:PlayAnimation("dropped_flower_cave"..data.animname)

        if not TheWorld.ismastersim then
            return inst
        end

        inst.entity:SetPristine()

        inst:AddComponent("deployable")
        inst.components.deployable.mode = DEPLOYMODE.PLANT
        inst.components.deployable.ondeploy = ondeploy
        inst.components.deployable.min_spacing = 4
        
        inst:AddComponent("stackable")
        inst.components.stackable.maxsize = TUNING.STACK_SIZE_LARGEITEM

        inst:AddComponent("inspectable")
        
        MakeMediumBurnable(inst, TUNING.MEDIUM_BURNTIME)
        MakeSmallPropagator(inst)

        inst:AddComponent("inventoryitem")
        inst.components.inventoryitem.atlasname = "images/inventoryimages/dug_"..data.name..".xml"
        
        return inst
    end

    return Prefab( "common/inventory/dug_flower_cave"..data.animname, fn, assets)
end

local data = { {name = "flower_cave", animname="", placer = "_single"}, 
               {name = "flower_cave_double", animname="_double", placer = "_double"},
               {name = "flower_cave_triple", animname="_triple", placer = "_triple"}
           }
local prefabs = {}

for k,v in pairs(data) do
    local flower = createflower(v)
    table.insert(prefabs, flower)
    table.insert(prefabs, MakePlacer( "common/dug_flower_cave"..v.animname.."_placer", "bulb_plant"..v.placer, "bulb_plant"..v.placer, "picked" ))
end

return unpack(prefabs) 
