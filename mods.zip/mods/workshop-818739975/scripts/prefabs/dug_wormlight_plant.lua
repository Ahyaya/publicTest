local assets =
{
    Asset("ANIM", "anim/dropped.zip"),
    Asset("ATLAS", "images/inventoryimages/dug_wormlight_plant.xml"),
    Asset("IMAGE", "images/inventoryimages/dug_wormlight_plant.tex"),
}


local function ondeploy(inst, pt)
	local tree = SpawnPrefab("wormlight_plant") 
	if tree then 
		tree.Transform:SetPosition(pt.x, pt.y, pt.z) 
		inst.components.stackable:Get():Remove()
		tree.components.pickable:OnTransplant()
		tree.SoundEmitter:PlaySound("dontstarve/wilson/plant_tree")
	end 
end


local function fn(Sim)
	local inst = CreateEntity()
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	MakeInventoryPhysics(inst)

	inst.AnimState:SetBank("dropped")
	inst.AnimState:SetBuild("dropped")
	inst.AnimState:PlayAnimation("dropped_wormlight_plant")


	if not TheWorld.ismastersim then
        return inst
    end

	inst.entity:SetPristine()

	inst:AddComponent("pickable")
	inst:AddComponent("stackable")
	inst.components.stackable.maxsize = TUNING.STACK_SIZE_LARGEITEM
	
	inst:AddComponent("inspectable")
	inst.components.inspectable.nameoverride = "dug_wormlight_plant"
	inst:AddComponent("inventoryitem")	
	inst.components.inventoryitem.atlasname = "images/inventoryimages/dug_wormlight_plant.xml"
    inst.components.inventoryitem.imagename = "dug_wormlight_plant" 

	inst:AddComponent("fuel")
	inst.components.fuel.fuelvalue = TUNING.LARGE_FUEL
    

	MakeMediumBurnable(inst)
    MakeSmallPropagator(inst)
	
    inst:AddComponent("deployable")
    inst.components.deployable.ondeploy = ondeploy
    inst.components.deployable.mode = DEPLOYMODE.PLANT
    inst.components.deployable.min_spacing = 2

	return inst      
end

return Prefab( "common/objects/dug_wormlight_plant", fn, assets),
	MakePlacer( "common/dug_wormlight_plant_placer", "wormlight_plant", "wormlight_plant", "picked")


