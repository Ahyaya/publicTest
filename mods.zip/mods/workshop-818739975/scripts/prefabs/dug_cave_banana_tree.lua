local assets=
{
    Asset("ANIM", "anim/dropped.zip"),
    Asset("ATLAS", "images/inventoryimages/dug_cave_banana_tree.xml"),
    Asset("IMAGE", "images/inventoryimages/dug_cave_banana_tree.tex"),

}

local function CanDeploy(inst) return true end

local function ondeploy(inst, pt)
	local tree = SpawnPrefab("cave_banana_tree") 
	if tree then 
		tree.Transform:SetPosition(pt.x, pt.y, pt.z) 
		inst.components.stackable:Get():Remove()
		tree.components.pickable:OnTransplant()
		tree.SoundEmitter:PlaySound("dontstarve/wilson/plant_tree")
	end 
end

	local function fn(Sim)
		local inst = CreateEntity()
		inst.entity:AddTransform()
		inst.entity:AddAnimState()
		inst.entity:AddNetwork()
		MakeInventoryPhysics(inst)
	    
		inst.AnimState:SetBank("dropped")
		inst.AnimState:SetBuild("dropped")
		inst.AnimState:PlayAnimation("dropped_banana")

		if not TheWorld.ismastersim then
			return inst
		end

		inst.entity:SetPristine()
		

		inst:AddComponent("pickable")
		inst:AddComponent("stackable")
		inst.components.stackable.maxsize = TUNING.STACK_SIZE_LARGEITEM
		
		inst:AddComponent("inspectable")
		inst.components.inspectable.nameoverride = "dug_cave_banana_tree"
		inst:AddComponent("inventoryitem")
		inst.components.inventoryitem.atlasname = "images/inventoryimages/dug_cave_banana_tree.xml"
	    inst.components.inventoryitem.imagename = "dug_cave_banana_tree"
		
		inst:AddComponent("fuel")
		inst.components.fuel.fuelvalue = TUNING.LARGE_FUEL
	    

        	MakeMediumBurnable(inst)
			MakeSmallPropagator(inst)
		
	    inst:AddComponent("deployable")
	    inst.components.deployable.ondeploy = ondeploy
	    inst.components.deployable.mode = DEPLOYMODE.PLANT
	    inst.components.deployable.min_spacing = 6
	    
		
	    
		---------------------  
		return inst      
	end

	return Prefab( "common/objects/dug_cave_banana_tree", fn, assets),
		MakePlacer( "common/dug_cave_banana_tree_placer", "cave_banana_tree", "cave_banana_tree", "idle_loop")