--[[
Copyright (C) 2018, 2019 Zarklord

This file is part of Gem Core.

The source code of this program is shared under the RECEX
SHARED SOURCE LICENSE (version 1.0).
The source code is shared for referrence and academic purposes
with the hope that people can read and learn from it. This is not
Free and Open Source software, and code is not redistributable
without permission of the author. Read the RECEX SHARED
SOURCE LICENSE for details 
The source codes does not come with any warranty including
the implied warranty of merchandise. 
You should have received a copy of the RECEX SHARED SOURCE
LICENSE in the form of a LICENSE file in the root of the source
directory. If not, please refer to 
<https://raw.githubusercontent.com/Recex/Licenses/master/SharedSourceLicense/LICENSE.txt>
]]
if not IsTheFrontEnd then
    local Customise = require("map/customise")

    gemrun("ondoinitgame", function(callback, savedata, profile, ...)
        local args = {...}
        local GetLevelDataOverride = UpvalueHacker.GetUpvalue(SaveGameIndex.StartSurvivalMode, "GetLevelDataOverride")
        local GetWorldgenOverride = UpvalueHacker.GetUpvalue(SaveGameIndex.StartSurvivalMode, "GetWorldgenOverride")

        --client hosted servers now properly save save games into the Cluster_XX folders!
        local saveslot = SaveGameIndex:GetCurrentSaveSlot()
        local serverdata = SaveGameIndex:GetSlotServerData(saveslot)
        local force_shard_path = serverdata ~= nil and serverdata.use_cluster_path and not TheNet:IsDedicated() and "Master" or nil

        savedata.map.topology.overrides.original = savedata.map.topology.overrides.original or {}
        local saveoverrides = {}
        for k, v in pairs(savedata.map.topology.overrides) do
            if savedata.map.topology.overrides.original[k] ~= v then
                saveoverrides[k] = v
            end
        end
        GetLevelDataOverride(saveslot, force_shard_path, function(leveldata)
            if leveldata and leveldata.overrides and savedata.map.topology then
                local original = savedata.map.topology.overrides
                original.original = nil
                savedata.map.topology.overrides = leveldata.overrides
                savedata.map.topology.overrides.original = original
            end
            GetWorldgenOverride(saveslot, force_shard_path, function(overridedata, frompreset)
                if overridedata and overridedata.overrides and savedata.map.topology then
                    if frompreset == true then
                        local original = savedata.map.topology.overrides
                        original.original = nil
                        savedata.map.topology.overrides = overridedata.overrides
                        savedata.map.topology.overrides.original = original
                    else
                        savedata.map.topology.overrides = MergeMapsDeep(savedata.map.topology.overrides, overridedata.overrides)
                        savedata.map.topology.overrides.original.original = nil
                    end
                end

                --put anything done manually back, after loading the leveldata and worldgen overrides.
                for k, v in pairs(saveoverrides) do
                    savedata.map.topology.overrides[k] = v
                end

                --prune out the "default" options.
                for k, v in pairs(savedata.map.topology.overrides) do
                    if k ~= "original" then
                        if v == Customise.GetDefaultForOption(k) then
                            savedata.map.topology.overrides[k] = nil
                        end
                    end
                end
                -- Clear out one time overrides
                if TheNet:GetCurrentSnapshot() > 2 then
                    local onetime = {"season_start", "autumn", "winter", "spring", "summer", "frograin", "wildfires", "prefabswaps_start", "rock_ice"}
                    for i,override in ipairs(onetime) do
                        if savedata.map.topology.overrides[override] ~= nil then
                            savedata.map.topology.overrides[override] = nil
                        end
                    end
                end
                callback(savedata, profile, unpack(args))
            end)
        end)
    end)
    return
end

local Customize = require("map/customise")

local GROUP = UpvalueHacker.GetUpvalue(Customize.ValidateOption, "GROUP")
local DEFAULT_GROUP = deepcopy(GROUP)

local defaultdescs = {}

defaultdescs.frequency_descriptions = deepcopy(GROUP.monsters.desc)
defaultdescs.starting_swaps_descriptions = deepcopy(GROUP.misc.items.prefabswaps_start.desc)
defaultdescs.petrification_descriptions = deepcopy(GROUP.misc.items.petrification.desc)
defaultdescs.speed_descriptions = deepcopy(GROUP.misc.items.regrowth.desc)
defaultdescs.disease_descriptions = deepcopy(GROUP.misc.items.disease_delay.desc)
defaultdescs.day_descriptions = deepcopy(GROUP.misc.items.day.desc)
defaultdescs.season_length_descriptions = deepcopy(GROUP.misc.items.autumn.desc)
defaultdescs.season_start_descriptions = deepcopy(GROUP.misc.items.season_start.desc)
defaultdescs.size_descriptions = deepcopy(GROUP.misc.items.world_size.desc)
defaultdescs.branching_descriptions = deepcopy(GROUP.misc.items.branching.desc)
defaultdescs.loop_descriptions = deepcopy(GROUP.misc.items.loop.desc)
defaultdescs.complexity_descriptions = deepcopy({
    {text = STRINGS.UI.SANDBOXMENU.SLIDEVERYSIMPLE, data = "verysimple"},
    {text = STRINGS.UI.SANDBOXMENU.SLIDESIMPLE, data = "simple"},
    {text = STRINGS.UI.SANDBOXMENU.SLIDEDEFAULT, data = "default"},
    {text = STRINGS.UI.SANDBOXMENU.SLIDECOMPLEX, data = "complex"},
    {text = STRINGS.UI.SANDBOXMENU.SLIDEVERYCOMPLEX, data = "verycomplex"},
})
defaultdescs.specialevent_descriptions = deepcopy(GROUP.misc.items.specialevent.desc)
defaultdescs.yesno_descriptions = deepcopy({
    {text = STRINGS.UI.SANDBOXMENU.YES, data = "default"},
    {text = STRINGS.UI.SANDBOXMENU.NO, data = "never"},
})

--HELPER FUNCTIONS
local function GetServerCreationScreen()
    for _, screen_in_stack in pairs(TheFrontEnd.screenstack) do
        if screen_in_stack.name == "ServerCreationScreen" then
            return screen_in_stack
        end
    end
end

local function RefreshWorldTabs()
    local servercreationscreen = GetServerCreationScreen()
    if servercreationscreen then
        for k, v in pairs(servercreationscreen.world_tabs) do
            v:Refresh()
        end
    end
end

local function GetNewGroupNumber()
    local max = 0
    for k, v in pairs(GROUP) do
        max = math.max(max, v.order)
    end
    return max + 1
end

local function GetNewItemNumber(GROUPNAME)
    local max = 0
    for k, v in pairs(GROUP[GROUPNAME].items) do
        max = math.max(max, v.order)
    end
    return max + 1
end

local function FixGroupOrder()
    local groups = {}
    for k,v in pairs(GROUP) do
        table.insert(groups,k)
    end
    table.sort(groups, function(a,b) return GROUP[a].order < GROUP[b].order end)
    for i, groupname in ipairs(groups) do
        GROUP[groupname].order = i
    end
end

local function FixItemOrder(GROUPNAME)
    local items = {}
    for k,v in pairs(GROUP[GROUPNAME].items) do
        table.insert(items, k)
    end
    table.sort(items, function(a,b) return GROUP[GROUPNAME].items[a].order < GROUP[GROUPNAME].items[b].order end)
    for i, itemname in ipairs(items) do
        GROUP[GROUPNAME].items[itemname].order = i
    end
end

local function MakeGroupItemList()
    local list = {}
    list.groups = {}
    list.items = setmetatable({}, {
        __index = function(items, groupname)
            rawset(items, groupname, setmetatable({_ = {}}, {
                __index = function(t, k)
                    local v = rawget(t, "_")[k]
                    if GetTableSize(rawget(t, "_")) == 0 then
                        rawset(items, groupname, nil)
                    end
                    return v
                end,
                __newindex = function(t, k, v)
                    rawset(t, "_")[k] = v
                    if GetTableSize(rawget(t, "_")) == 0 then
                        rawset(items, groupname, nil)
                    end
                end
            }))
            return rawget(items, groupname)
        end,
    })
    return list
end
--END HELPER FUNCTIONS

FixGroupOrder()
for k, v in pairs(GROUP) do
    FixItemOrder(k)
end
RefreshWorldTabs()

local CUSTOMGROUPLABELS = {}

local modifiers = {}
--PUBLIC INTERFACE
local WorldGenOptions = Class(function(self, modname)
    assert(KnownModIndex:DoesModExistAnyVersion(modname), "modname "..modname.." must refer to a valid mod!")
    self.modname = modname
    modifiers[modname] = {
        wgo = self,
        added = MakeGroupItemList(),
        removed = MakeGroupItemList(),
        reorder = MakeGroupItemList(),
        modified_properties = MakeGroupItemList(),
        modified_values = MakeGroupItemList(),
    }
    function self:GetModifier()
        return modifiers[modname]
    end
end, nil, {})

function WorldGenOptions:AddGroup(GROUPNAME, groupsettings)
    if groupsettings.customtext then
        CUSTOMGROUPLABELS[GROUPNAME] = groupsettings.customtext
        groupsettings.text = groupsettings.customtext
    end
    groupsettings.order = GetNewGroupNumber()
    GROUP[GROUPNAME] = groupsettings

    self:GetModifier().added.groups[GROUPNAME] = true
    --remove this from the removed list if it was added back by this mod.
    self:GetModifier().removed.groups[GROUPNAME] = nil

    FixItemOrder(GROUPNAME)
    RefreshWorldTabs()
end

function WorldGenOptions:AddItemToGroup(GROUPNAME, ITEMNAME, itemsettings)
    itemsettings.order = GetNewItemNumber(GROUPNAME)
    GROUP[GROUPNAME].items[ITEMNAME] = itemsettings

    self:GetModifier().added.items[GROUPNAME][ITEMNAME] = true
    --remove this from the removed list if it was added back by this mod.
    self:GetModifier().removed.items[GROUPNAME][ITEMNAME] = nil

    RefreshWorldTabs()
end

function WorldGenOptions:RemoveGroup(GROUPNAME)
    GROUP[GROUPNAME] = nil

    --if this mod added the group, just remove it from the added list, otherwise mark this as a removed group.
    if self:GetModifier().added.groups[GROUPNAME] then
        self:GetModifier().added.groups[GROUPNAME] = nil
    else
        self:GetModifier().removed.groups[GROUPNAME] = true
    end

    FixGroupOrder()
    RefreshWorldTabs()
end

function WorldGenOptions:RemoveItemFromGroup(GROUPNAME, ITEMNAME)
    GROUP[GROUPNAME].items[ITEMNAME] = nil
    --if this mod added the item, just remove it from the added list, otherwise mark this as a removed item.
    if self:GetModifier().added.items[GROUPNAME][ITEMNAME] then
        self:GetModifier().added.items[GROUPNAME][ITEMNAME] = nil
    else
        self:GetModifier().removed.items[GROUPNAME][ITEMNAME] = true
    end
    FixItemOrder(GROUPNAME)
    RefreshWorldTabs()
end

function WorldGenOptions:ReorderGroup(GROUPNAME, TARGETGROUPNAME, moveafter)
    GROUP[GROUPNAME].order = GROUP[TARGETGROUPNAME].order + (moveafter and 0.1 or -0.1)
    FixGroupOrder()
    RefreshWorldTabs()
end

function WorldGenOptions:ReorderItem(GROUPNAME, ITEMNAME, TARGETITEMNAME, moveafter)
    GROUP[GROUPNAME].items[ITEMNAME].order = GROUP[GROUPNAME].items[TARGETITEMNAME].order + (moveafter and 0.1 or -0.1)
    FixItemOrder(GROUPNAME)
    RefreshWorldTabs()
end

local blacklist = {
    ["order"] = true,
    ["items"] = true,
}

function WorldGenOptions:SetGroupProperty(GROUPNAME, property, value)
    if not blacklist[property] then
        GROUP[GROUPNAME][property] = value
    end
    RefreshWorldTabs()
end

function WorldGenOptions:SetItemProperty(GROUPNAME, ITEMNAME, property, value)
    if not blacklist[property] then
        GROUP[GROUPNAME].items[ITEMNAME][property] = value
    end
    if property == "alwaysedit" or property == "neveredit" then
        local servercreationscreen = GetServerCreationScreen()
        if servercreationscreen then
            for i, tab in ipairs(servercreationscreen.world_tabs) do
                if tab.customizationlist ~= nil then
                    for k, v in pairs(tab.customizationlist.options) do
                        if v.group == GROUPNAME and v.name == ITEMNAME then
                            v[property] = value
                            break
                        end
                    end
                    tab.customizationlist.scroll_list:RefreshView()
                end
            end 
        end
    else
        RefreshWorldTabs()
    end
end

function WorldGenOptions:GetGroupProperty(GROUPNAME, property)
    if not blacklist[property] then
        return GROUP[GROUPNAME][property]
    end
end

function WorldGenOptions:GetItemProperty(GROUPNAME, ITEMNAME, property)
    if not blacklist[property] then
        return GROUP[GROUPNAME].items[ITEMNAME][property]
    end
end

local event_listeners = {}

function WorldGenOptions:ListenForEvent(modname, event, fn)
    if not event_listeners[modname] then
        event_listeners[modname] = {}
    end
    if not event_listeners[modname][event] then
        event_listeners[modname][event] = {}
    end
    table.insert(event_listeners[modname][event], fn)
end

function WorldGenOptions:RemoveEventCallback(modname, event, fn)
    table.removearrayvalue(event_listeners[modname] and event_listeners[modname][event] or {}, fn)
    if GetTableSize(event_listeners[modname] and event_listeners[modname][event]) == 0 then
        event_listeners[modname][event] = nil
    end
    if GetTableSize(event_listeners[modname]) == 0 then
        event_listeners[modname] = nil
    end
end

function WorldGenOptions:SetOptionValue(location, option, value)
    local servercreationscreen = GetServerCreationScreen()
    if servercreationscreen then
        for i, tab in ipairs(servercreationscreen.world_tabs) do
            if location == tab:GetLocationForLevel(tab.currentmultilevel) then
                if tab.customizationlist ~= nil then
                    tab.customizationlist:SetValueForOption(option, value)
                    tab.current_option_settings[tab.currentmultilevel].tweaks[option] = value
                end
            end 
        end
    end
end

function WorldGenOptions:GetOptionValue(location, option)
    local servercreationscreen = GetServerCreationScreen()
    if servercreationscreen then
        for i, tab in ipairs(servercreationscreen.world_tabs) do
            if location == tab:GetLocationForLevel(tab.currentmultilevel) then
                if tab.customizationlist ~= nil then
                    for i, data in pairs(tab.customizationlist.optionitems) do
                        if data.option and data.option.name == option then
                            return data.selection
                        end
                    end
                end
            end 
        end
    end
end

function WorldGenOptions:__index(name)
    return defaultdescs[name] == nil and getmetatable(self)[name] or deepcopy(defaultdescs[name])
end
--END PUBLIC INTERFACE

local function PushWorldGenEvent(event, ...)
    for modname, listeners in pairs(event_listeners) do
        for i, fn in ipairs(listeners[event] or {}) do
            fn(...)
        end
    end
end

--FUNCTION REPLACEMENTS
local FrontendHelper = gemrun("tools/frontendhelper", GEMENV.modname)

FrontendHelper.ReplaceFunction(Customize, "GetOptions", function(_GetOptions, ...)
    local options = _GetOptions(...)
    for i, v in ipairs(options) do
        options[i].atlas = GROUP[v.group].items[v.name].atlas or nil
        options[i].alwaysedit = GROUP[v.group].items[v.name].alwaysedit or nil
        options[i].neveredit = GROUP[v.group].items[v.name].neveredit or nil
    end
    return options
end)

FrontendHelper.DoOnce(UpvalueHacker.SetUpvalue, Customize.GetOptionsWithLocationDefaults, function(...)
    return Customize.GetOptions(...)
end, "GetOptions")

FrontendHelper.ReplaceFunction(string, "format", function(_stringformat, fmt, opt1, opt2, opt3, ...)
    if fmt == "%s %s" and table.contains(STRINGS.UI.SANDBOXMENU.LOCATION, opt1) and table.contains(CUSTOMGROUPLABELS, opt2) and opt3 == nil then
        fmt = "%s"
        return _stringformat(fmt, opt2)
    end
    return _stringformat(fmt, opt1, opt2, opt3, ...)
end)

local ServerCreationScreen = require("screens/redux/servercreationscreen")

FrontendHelper.ReplaceFunction(ServerCreationScreen, "OnBecomeActive", function(_OnBecomeActive, self, ...)
    local retval = {_OnBecomeActive(self, ...)}
    PushWorldGenEvent("becomeactive", self)
    return unpack(retval)
end)

local WorldCustomizationTab = require("widgets/redux/worldcustomizationtab")

FrontendHelper.ReplaceFunction(WorldCustomizationTab, "AddMultiLevel", function(_AddMultiLevel, self, level, ...)
    PushWorldGenEvent("addlocation", self:GetLocationForLevel(level))
    return _AddMultiLevel(self, level, ...)
end)

FrontendHelper.ReplaceFunction(WorldCustomizationTab, "RemoveMultiLevel", function(_RemoveMultiLevel, self, level, ...)
    PushWorldGenEvent("removelocation", self:GetLocationForLevel(level))
    return _RemoveMultiLevel(self, level, ...)
end)

local worldoptions

FrontendHelper.ReplaceFunction(WorldCustomizationTab, "CollectOptions", function(_CollectOptions, self, ...)
    --incase CollectOptions is overriden multiple times
    local stacklevel = 2
    local tabidx
    while debug.getinfo(stacklevel, "n") ~= nil do
        worldoptions = LocalVariableHacker.GetLocalVariable(stacklevel, "worldoptions")
        tabidx = LocalVariableHacker.GetLocalVariable(stacklevel, "i")
        if worldoptions ~= nil and tabidx ~= nil then
            break
        end
        stacklevel = stacklevel + 1
    end
    if tabidx == GetTableSize(self.servercreationscreen.world_tabs) then
        local ret = _CollectOptions(self, ...)
        worldoptions[tabidx] = ret
        PushWorldGenEvent("postcollectoptions", worldoptions)
        return ret
    end
    return _CollectOptions(self, ...)
end)

local CURRENT_LEVEL_LOCATIONS = SERVER_LEVEL_LOCATIONS

FrontendHelper.ReplaceFunction(WorldCustomizationTab, "OnChangeGameMode", function(_OnChangeGameMode, self, gamemode, ...)
    local leveltype = GetLevelType(gamemode)
    if EVENTSERVER_LEVEL_LOCATIONS[leveltype] ~= nil then
        CURRENT_LEVEL_LOCATIONS = EVENTSERVER_LEVEL_LOCATIONS[leveltype]
    else
        CURRENT_LEVEL_LOCATIONS = SERVER_LEVEL_LOCATIONS
    end
    return _OnChangeGameMode(self, gamemode, ...)
end)

local Levels = require("map/levels")

FrontendHelper.ReplaceFunction(WorldCustomizationTab, "LoadPreset", function(_LoadPreset, self, preset, ...)
    local retvals = {_LoadPreset(self, preset, ...)}
    PushWorldGenEvent("loadpreset", preset, preset ~= nil and Levels.GetDataForLevelID(preset) or
        Levels.GetDefaultLevelData(GetLevelType(self.servercreationscreen:GetGameMode()), CURRENT_LEVEL_LOCATIONS[self.tab_location_index]) or
        Levels.GetDataForLevelID("MOD_MISSING"))
    return unpack(retvals)
end)

FrontendHelper.ReplaceFunction(WorldCustomizationTab, "StartSurvivalMode", function(_StartSurvivalMode, self, ...)
    worldoptions = nil
    return _StartSurvivalMode(self, ...)
end)

FrontendHelper.ReplaceFunction(WorldCustomizationTab, "UpdateServerData", function(_UpdateServerData, self, saveslot, ...)
    if worldoptions ~= nil then
        self.data.slots[saveslot].world.options = worldoptions
        worldoptions = nil
    end
    return _UpdateServerData(self, saveslot, ...)
end)
--END FUNCTION REPLACEMENTS

FrontendHelper.DoOnce(GEMENV.AddClassPostConstruct, "widgets/redux/worldcustomizationlist", function(inst)
    local _spinnerCB = inst.spinnerCB
    function inst.spinnerCB(option, value, ...)
        PushWorldGenEvent("anyoptionchange", inst.location, option, value)
        PushWorldGenEvent(option.."optionchange", inst.location, value)
        return _spinnerCB(option, value, ...)
    end

    local _update_fn = inst.scroll_list.update_fn
    function inst.scroll_list.update_fn(context, widget, data, index, ...)
        local retval = {_update_fn(context, widget, data, index, ...)}
        if not data or data.is_empty then
            return unpack(retval)
        end

        if data.heading_text then
            return unpack(retval)
        end
        if widget.opt_spinner.data.option.neveredit then
            widget.opt_spinner.spinner:SetEditable(false)
        else
            widget.opt_spinner.spinner:SetEditable(inst.allowEdit or widget.opt_spinner.data.option.alwaysedit)
        end
        return unpack(retval)
    end
end)

gemrun("unloadmodany", function(modname)
    if modname then
        event_listeners[modname] = nil
    end
end)

gemrun("unloadgemcore", function()
    GROUP = deepcopy(DEFAULT_GROUP)
    UpvalueHacker.SetUpvalue(Customize.ValidateOption, GROUP, "GROUP")
    RefreshWorldTabs()
    event_listeners = {}
end)

local args = {...}
local functionname = args[1]
local modname = args[2]

local MakeGemFunction = gemrun("gemfunctionmanager")
MakeGemFunction(functionname, function(functionname, modname, ...) return WorldGenOptions(modname) end, true)
return WorldGenOptions(modname)