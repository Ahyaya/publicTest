--[[
Copyright (C) 2019 Zarklord

This file is part of Gem Core.

The source code of this program is shared under the RECEX
SHARED SOURCE LICENSE (version 1.0).
The source code is shared for referrence and academic purposes
with the hope that people can read and learn from it. This is not
Free and Open Source software, and code is not redistributable
without permission of the author. Read the RECEX SHARED
SOURCE LICENSE for details 
The source codes does not come with any warranty including
the implied warranty of merchandise. 
You should have received a copy of the RECEX SHARED SOURCE
LICENSE in the form of a LICENSE file in the root of the source
directory. If not, please refer to 
<https://raw.githubusercontent.com/Recex/Licenses/master/SharedSourceLicense/LICENSE.txt>
]]

local permodconfigs = {}
local dirty = {}
local function GeneratePerModConfigOptions(_modname)
    local configsets = {}
    for optionname, data in pairs(permodconfigs[_modname] or {}) do
        local moddirnames = TheSim:GetModDirectoryNames()
        local configdata = {}
        for _, modname in ipairs(moddirnames) do
            if not (data.options.exclude_self and _modname == modname) then
                local modinfo = KnownModIndex:GetModInfo(modname)
                if modinfo and (not data.options.client_only or modinfo.client_only_mod) and (not data.options.server_only or not modinfo.client_only_mod) then
                    local config = deepcopy(data.template)
                    config.label = modinfo.name
                    config.name = optionname:gsub(" ", "_")..modname:gsub(" ", "_")
                    table.insert(configdata, config)
                end
            end
        end 

        table.sort(configdata, function(a,b)
            if not a.label then return false end
            if not b.label then return true end
            return string.lower(a.label) < string.lower(b.label)
        end)
        if data.options.master_override then
            local master_override = deepcopy(data.options.master_override)
            master_override.label = "Master Option"
            master_override.name = optionname:gsub(" ", "_").."master_override"
            master_override.hover = "Sets the default value for every mod."
            table.insert(configdata, 1, master_override)
        end
        table.insert(configdata, 1, {
            name = optionname..":",
            options = {{description="", data=false}}, 
            default = false,
        })
        table.insert(configsets, configdata)
    end
    return configsets
end

--mostly copied from modindex@line323
local function RefreshModConfigOptions(modname)
    local env = (KnownModIndex:LoadModOverides() or {})[modname]
    if env and env.configuration_options ~= nil then
        local actual_modname = ResolveModname(modname)
        if actual_modname ~= nil then
            local force_local_options = true
            local config_options, _ = KnownModIndex:GetModConfigurationOptions_Internal(actual_modname,force_local_options)
            if config_options and type(config_options) == "table" then
                for option, override in pairs(env.configuration_options) do
                    for _, config_option in pairs(config_options) do
                        if config_option.name == option then
                            config_option.saved = override
                        end
                    end
                end
            end
        end
    end
end

local function ApplyPerModConfigOptions(modname)
    local _info = KnownModIndex:GetModInfo(modname)
    _info.gemcore_configuration_start = _info.gemcore_configuration_start or #(_info.configuration_options or {}) + 1
    if dirty[modname] and _info.configuration_options[_info.gemcore_configuration_start] ~= nil then
        for i = _info.gemcore_configuration_start, #_info.configuration_options do
            _info.configuration_options[i] = nil
        end
        dirty[modname] = false
    end
    if #(_info.configuration_options or {}) + 1 == _info.gemcore_configuration_start then
        local options = GeneratePerModConfigOptions(modname)
        for i, v in ipairs(options) do
            for i1, v1 in ipairs(v) do
                table.insert(_info.configuration_options, v1)
            end
        end
        RefreshModConfigOptions(modname)
    end
end

if IsTheFrontEnd then
    local ModsTab = require("widgets/redux/modstab")
    local FrontendHelper = gemrun("tools/frontendhelper", GEMENV.modname)

    FrontendHelper.ReplaceFunction(ModsTab, "ShowModDetails", function(_ShowModDetails, self, idx, client_mod, ...)
        local modnames_versions = client_mod and self.modnames_client or self.modnames_server
        ApplyPerModConfigOptions(modnames_versions[idx].modname)
        return _ShowModDetails(self, idx, client_mod, ...)
    end)

    FrontendHelper.ReplaceFunction(ModsTab, "ReloadModInfoPrefabs", function(_ReloadModInfoPrefabs, self, ...)
        for k, v in pairs(dirty) do
            dirty[k] = true
        end
        return _ReloadModInfoPrefabs(self, ...)
    end)

    FrontendHelper.ReplaceFunction(KnownModIndex, "LoadModConfigurationOptions", function(_LoadModConfigurationOptions, self, modname, ...)
        ApplyPerModConfigOptions(modname)
        return _LoadModConfigurationOptions(self, modname, ...)
    end)
else
    local _LoadModConfigurationOptions = KnownModIndex.LoadModConfigurationOptions
    function KnownModIndex:LoadModConfigurationOptions(modname, ...)
        ApplyPerModConfigOptions(modname)
        return _LoadModConfigurationOptions(self, modname, ...)
    end
end

--[[
template = {
    hover = "hover text",
    options = {
        {
            description = "description",
            data = false,
            hover = "hover text when disabled."
        },
        {
            description = "description",
            data = true,
            hover = "hover text when enabled."
        }
    }, 
    default = true,
}
]]

local MakeGemFunction = gemrun("gemfunctionmanager")
MakeGemFunction("addpermodconfig", function(functionname, modname, optionname, template, options, ...)
    local modconfig = permodconfigs[modname]
    if not modconfig then
        modconfig = {}
        permodconfigs[modname] = modconfig
    end
    modconfig[optionname] = {template = template, options = options or {}}
    dirty[modname] = true
end, true)

function GetModModConfigData(optionname, modmodname, modname, get_local_config)
    ApplyPerModConfigOptions(modname)
    local value = GetModConfigData(optionname:gsub(" ", "_")..modmodname:gsub(" ", "_"), modname, get_local_config)
    if value == "default" then
        value = GetModConfigData(optionname:gsub(" ", "_").."master_override", modname, get_local_config)
    end
    return value
end