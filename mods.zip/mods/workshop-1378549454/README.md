# GemCore

## Credits:

* Zarklord - For creating this API.
* Fidooop - For ensuring things were done right.
* Rezecib - For his wonderful upvalue hacker.
* NSimplex - For memspikefix.
