name = "DST PickyPickyPicky"
description = "Makes most everything quick pick!"
author = "Afro1967"
version = "2.0"
forumthread = ""

api_version = 10

all_clients_require_mod = true
dst_compatible = true
client_only_mod = false

icon_atlas = "PickyPickyPicky.xml"
icon = "PickyPickyPicky.tex"
