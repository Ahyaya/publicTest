function PPP_QuickPick(inst)
	if inst.components.pickable then
	inst.components.pickable.quickpick = true
	end
end

AddPrefabPostInit("grass", PPP_QuickPick)
AddPrefabPostInit("sapling", PPP_QuickPick)
AddPrefabPostInit("reeds", PPP_QuickPick)
AddPrefabPostInit("reeds", PPP_QuickPick)
AddPrefabPostInit("berrybush", PPP_QuickPick)
AddPrefabPostInit("berrybush2", PPP_QuickPick)
AddPrefabPostInit("cactus", PPP_QuickPick)
AddPrefabPostInit("cave_fern", PPP_QuickPick)
AddPrefabPostInit("red_mushroom", PPP_QuickPick)
AddPrefabPostInit("green_mushroom", PPP_QuickPick)
AddPrefabPostInit("blue_mushroom", PPP_QuickPick)
AddPrefabPostInit("cave_banana_tree", PPP_QuickPick)
AddPrefabPostInit("hybrid_banana_tree", PPP_QuickPick)
AddPrefabPostInit("lichen", PPP_QuickPick)
AddPrefabPostInit("marsh_bush", PPP_QuickPick)
AddPrefabPostInit("flower_cave", PPP_QuickPick)
AddPrefabPostInit("flower_cave_double", PPP_QuickPick)
AddPrefabPostInit("flower_cave_triple", PPP_QuickPick)
AddPrefabPostInit("seaweed_planted", PPP_QuickPick)
AddPrefabPostInit("limpetrock", PPP_QuickPick)
AddPrefabPostInit("mussel_farm", PPP_QuickPick)
AddPrefabPostInit("grass_water", PPP_QuickPick)
AddPrefabPostInit("sweet_potato_planted", PPP_QuickPick)
AddPrefabPostInit("coffeebush", PPP_QuickPick)
AddPrefabPostInit("seashell_beached", PPP_QuickPick)
AddPrefabPostInit("berrybush_juicy", PPP_QuickPick)
AddPrefabPostInit("coral_brain_rock", PPP_QuickPick)











