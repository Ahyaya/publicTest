name = "  更有用的帽子们MORE Helpful Hats"
description = 
"让穿戴栏中的一些道具更有用\n"..
"MORE Helpful Dress\n"


author = "任天涯"
version = "1.0.016"
forumthread = "有问题可以联系QQ：200551240"
api_version = 10


all_clients_require_mod = true

client_only_mod = false

dst_compatible = true

server_filter_tags = {"rty200551240","cjmz","超级帽子"}


priority = -9999

icon_atlas = "preview.xml"
icon = "preview.tex"



configuration_options =
{   
    {
        name = "language",
        label = "语言Language",
	hover = "Language",
        options =
        {
            {description = "简体中文", data = 0, 
	    hover = "Chinese",
	    },
            {description = "English", data = 1, 
	    hover = "英语",
	    },
        },
        default = 0,
    },
}