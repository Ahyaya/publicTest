local assets =
{
    Asset("ANIM", "anim/flowers.zip"),
}

local prefabs =
{
    "flower_evil",
    "flower_withered",
}

local DAYLIGHT_SEARCH_RANGE = 30

local names = {"f1","f2","f3","f4","f5","f6","f7","f8","f9","f10"}
local ROSE_NAME = "rose"
local ROSE_CHANCE = 0.01

local function setflowertype(inst, name)
    if inst.animname == nil or (name ~= nil and inst.animname ~= name) then
        if inst.animname == ROSE_NAME then
            inst:RemoveTag("thorny")
        end
        inst.animname = name or (math.random() < ROSE_CHANCE and ROSE_NAME or names[math.random(#names)])
        inst.AnimState:PlayAnimation(inst.animname)
        if inst.animname == ROSE_NAME then
            inst:AddTag("thorny")
        end
    end
end

local function onsave(inst, data)
    data.anim = inst.animname
    data.planted = inst.planted
end

local function onload(inst, data)
    setflowertype(inst, data ~= nil and data.anim or nil)
    inst.planted = data ~= nil and data.planted or nil
end



local function GetStatus(inst)
    return inst.animname == ROSE_NAME and "ROSE" or nil
end

local function fn()
    local inst = CreateEntity()

    inst.entity:AddTransform()
    inst.entity:AddAnimState()
    inst.entity:AddNetwork()

    inst.AnimState:SetBank("flowers")
    inst.AnimState:SetBuild("flowers")
    inst.AnimState:SetRayTestOnBB(true)

    inst:AddTag("flower")
    
    inst:AddTag("NOBLOCK")
    inst:AddTag("NOCLICK")

    inst.entity:SetPristine()

    if not TheWorld.ismastersim then
        return inst
    end

    inst:AddComponent("inspectable")
    inst.components.inspectable.getstatus = GetStatus

    if not POPULATING then
        setflowertype(inst)
    end
    inst:DoTaskInTime(2, inst.Remove)
    --------SaveLoad
    inst.OnSave = onsave
    inst.OnLoad = onload

    return inst
end

function rosefn()
    local inst = fn()

    inst:SetPrefabName("flower")

    if not TheWorld.ismastersim then
        return inst
    end

    setflowertype(inst, ROSE_NAME)

    return inst
end

return Prefab("tyflower", fn, assets, prefabs),
       Prefab("tyflower_rose", rosefn, assets, prefabs)
