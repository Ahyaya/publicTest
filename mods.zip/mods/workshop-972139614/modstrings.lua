local lan = GetModConfigData("language")
--简体中文--------
STRINGS_CHS = {
	TYWORDS={		
		----更有用的帽子
		TYWORDS_73_0="戴",
		TYWORDS_73_1="可以不被蛰，并且获得更多蜂蜜",
		TYWORDS_73_2="可以收获更多作物",
		TYWORDS_73_3="可以收获更多食物",
		TYWORDS_73_4="可以更专业的烹饪食物",
		TYWORDS_73_5="可以收获更多",
		TYWORDS_73_6="可以获得更多",
		TYWORDS_73_7="可以更快速的钓鱼",
		TYWORDS_73_8="一条鱼都看不到",
		
	},
}
--英文--------
STRINGS_EN  = {
	TYWORDS={
		----更有用的帽子
		TYWORDS_73_0="wear ",
		TYWORDS_73_1=" can Get more honey",
		TYWORDS_73_2=" can Get more crop",
		TYWORDS_73_3=" can Get more food",
		TYWORDS_73_4=" can Cook more quickly",
		TYWORDS_73_5=" can Get more ",
		TYWORDS_73_6=" can Get more ",
		TYWORDS_73_7=" you will fish more quickly",
		TYWORDS_73_8=" There's nothing here",
	},
}

GLOBAL.modstr=nil
local function getStr(str)
	return str
end
if lan==0 then
	modstr=getStr(STRINGS_CHS)
	GLOBAL.TYWORDS=modstr.TYWORDS
else
	modstr=getStr(STRINGS_EN)
	GLOBAL.TYWORDS=modstr.TYWORDS
end